(function () {
  /* ─────────────────────────────── STATE ────────────────────────────────── */
  const STATE = {
    mode: "chats",
    enabled: false,
    selectedIds: new Set(),
    lastSelectedId: null,
    searchTerm: "",
    exactSearch: false,
    selectedYear: "all",
    selectedProjectKey: "all",
    resultScope: "auto",
    cachedSortOrder: "newest",
    resultsCollapsed: true,
    syncingAll: false,
    deleting: false,
    deleteProgress: { current: 0, total: 0 },
    deleteCooldown: null,
    accountKey: null,
    cachedConversations: [],
    projectIndex: { projects: [], memberships: {} },
    cacheLoadedAt: null,
    skipDeleteWarning: false,
    uiHidden: false,
    reviewSessionCount: 0,
    reviewPromptHidden: false,
    library: GPTBDLibraryUi?.createState?.() || {
      files: [], selectedIds: new Set(), searchTerm: "", syncing: false,
      cacheLoadedAt: null, accountKey: null, syncApiAvailable: null, deleteApiAvailable: null,
      visibleLimit: 50, lastError: "", isComplete: false, syncRunId: 0, deletePending: false
    },
    health: {
      checkedAt: 0,
      running: false,
      syncAvailable: true,
      deleteApiAvailable: true,
      deleteUiAvailable: true,
      safeMode: false,
      note: "",
      issues: []
    },
    failureCounts: {
      sync: 0,
      deleteApi: 0,
      deleteUi: 0
    },
    observer: null,
    refreshTimer: null,
    healthTimer: null,
    deleteCooldownTimer: null
  };

  const CACHE_KEY = "gptbd-conversation-cache-v1";
  const SYNC_CHECKPOINT_KEY = "gptbd-sync-checkpoint-v1";
  const SYNC_CHECKPOINT_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;
  const DELETE_COOLDOWN_KEY = "gptbd-delete-cooldown-v1";
  const DEFAULT_DELETE_COOLDOWN_MS = 2 * 60 * 1000;
  const PROJECT_CACHE_KEY = "gptbd-project-cache-v1";
  const UI_HIDDEN_KEY = "gptbd-ui-hidden";
  const TOOLBAR_MODE_KEY = "gptbd-toolbar-mode";
  const SKIP_DELETE_WARNING_KEY = "gptbd-skip-delete-warning";
  const REVIEW_SESSION_COUNT_KEY = "gptbd-review-session-count";
  const REVIEW_PROMPT_HIDDEN_KEY = "gptbd-review-prompt-hidden";
  const REVIEW_SESSION_MARK_KEY = "gptbd-review-session-marked";
  const REVIEW_PROMPT_THRESHOLD = 3;
  const APP_VERSION = chrome?.runtime?.getManifest?.().version || "1.0.0";
  const MARK_ICON_URL = chrome?.runtime?.getURL?.("icons/icon-48.png") || "";
  const REPO_BASE_URL = "https://github.com/johnvouros/ChatGPT-bulk-delete-chats";
  const CHROME_REVIEW_URL = "https://chromewebstore.google.com/detail/chatgpt-bulk-delete/nbecbefmhjidfmmfbpealakgpnnldcce/reviews";
  const FIREFOX_REVIEW_URL = "https://addons.mozilla.org/en-GB/firefox/addon/chatgpt-chat-bulk-delete/reviews/";
  const DOC_LINKS = {
    privacy: `${REPO_BASE_URL}/blob/main/PRIVACY.md`,
    license: `${REPO_BASE_URL}/blob/main/LICENSE`,
    terms: `${REPO_BASE_URL}/blob/main/TERMS.md`,
    bugs: `${REPO_BASE_URL}/issues/new`
  };
  const DEFAULT_DELETE_MODAL_SUBTITLE = "Permanent. ChatGPT does not support undo.";
  const DEFAULT_DELETE_MODAL_WARNING = "Delete is permanent and cannot be recovered.";
  const CAPABILITY_REFRESH_MS = 10 * 60 * 1000;
  const CAPABILITY_RETRY_MS = 90 * 1000;
  const CAPABILITY_FAILURE_THRESHOLD = 2;
  const LIBRARY_THUMBNAIL_CONCURRENCY = 4;
  const LIBRARY_THUMBNAIL_PATH = "/backend-api/estuary/content";
  let libraryThumbnailObserver = null;
  let libraryThumbnailActive = 0;
  let libraryThumbnailGeneration = 0;
  const libraryThumbnailQueue = [];
  const libraryThumbnailUrls = new Map();
  const libraryThumbnailLoading = new Map();
  const libraryThumbnailControllers = new Map();
  const libraryAutoSyncAttempts = new Set();
  let lastLibrarySessionAccountKey;

  /* ───────────────────────────── SELECTORS ──────────────────────────────── */
  const SELECTORS = {
    conversationLinks: [
      'a[href^="/c/"]',
      'a[href*="/c/"]',
      'a[href*="://chatgpt.com/c/"]',
      'a[href*="://chat.openai.com/c/"]',
      '[role="link"][href*="/c/"]',
      '[data-href*="/c/"]'
    ].join(", "),
    sidebarRoots: ["nav", "aside", '[data-testid="history"]'].join(", "),
    projectSignals: [
      '[data-testid*="project" i]',
      '[aria-label*="project" i]',
      '[href*="/project"]',
      '[href*="/projects"]'
    ].join(", "),
    projectLinks: [
      'a[href*="/project" i]',
      'a[href*="/projects" i]',
      'a[href*="/g/g-p-" i]'
    ].join(", "),
    messageRoots: [
      "article",
      '[data-testid*="conversation-turn" i]',
      '[data-message-author-role]',
      '[data-message-id]',
      ".markdown"
    ].join(", "),
    menuButtons: [
      'button[aria-haspopup="menu"]',
      'button[aria-expanded]',
      'button[aria-label*="More"]',
      'button[aria-label*="more"]',
      '[id^="radix-"]',
      'button[data-testid*="history-item"]',
      'button[data-testid*="conversation"]'
    ].join(", "),
    menuItems: [
      '[role="menuitem"]',
      'button',
      '[data-radix-collection-item]'
    ].join(", "),
    dialogs: ['[role="dialog"]', '[aria-modal="true"]'].join(", ")
  };

  /* modal resolve handle — set by showDeleteModal, cleared on resolution */
  let activeModalResolve = null;
  let runtimeBridgeReady = false;
  let observedRoutePath = window.location.pathname;
  let routeCheckQueued = false;

  /* ─────────────────────────────── BOOT ─────────────────────────────────── */
  function boot() {
    if (window.top !== window.self) return;
    injectShell();
    refreshConversationRows();
    observeDom();
    observeRouteChanges();
    observePreferenceChanges();
    setupRuntimeBridge();
    render();
    if (STATE.mode === "library" && !STATE.uiHidden) void ensureLibraryCacheForCurrentAccount();
    window.addEventListener("focus", () => {
      void ensureCapabilityHealth({ force: isCapabilityHealthStale(), silent: true });
      if (STATE.mode === "library" && !STATE.uiHidden) void ensureLibraryCacheForCurrentAccount();
    });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        void ensureCapabilityHealth({ force: isCapabilityHealthStale(), silent: true });
        if (STATE.mode === "library" && !STATE.uiHidden) void ensureLibraryCacheForCurrentAccount();
      }
    });
    window.addEventListener("pagehide", () => revokeLibraryThumbnails());
    void ensureCapabilityHealth({ force: true, silent: true });
  }

  function observeRouteChanges() {
    if (observeRouteChanges.bound) return;
    observeRouteChanges.bound = true;
    const schedule = () => {
      if (routeCheckQueued) return;
      routeCheckQueued = true;
      window.queueMicrotask(() => {
        routeCheckQueued = false;
        applyLibraryRouteMode();
      });
    };
    window.addEventListener("popstate", schedule);
    ["pushState", "replaceState"].forEach(method => {
      const original = window.history?.[method];
      if (typeof original !== "function") return;
      window.history[method] = function (...args) {
        const result = original.apply(this, args);
        schedule();
        return result;
      };
    });
  }

  function applyLibraryRouteMode() {
    const path = window.location.pathname;
    if (!isLibraryRoute()) {
      observedRoutePath = path;
      return;
    }
    // A user can deliberately keep Chats selected while remaining on the
    // Library page; only an actual route transition changes the mode.
    if (path === observedRoutePath) return;
    // Retain a Library route transition until the active operation releases
    // the toolbar; the DOM observer will then apply it.
    if (STATE.deleting || STATE.syncingAll || STATE.library.syncing || STATE.library.deletePending) return;
    observedRoutePath = path;
    STATE.mode = "library";
    STATE.enabled = false;
    STATE.selectedIds.clear();
    STATE.lastSelectedId = null;
    refreshConversationRows();
    render();
    if (!STATE.uiHidden) void ensureLibraryCacheForCurrentAccount();
  }

  /* ───────────────────────────── SHELL HTML ─────────────────────────────── */
  function injectShell() {
    if (document.getElementById("gpt-bulk-delete-root")) return;

    const root = document.createElement("div");
    root.id = "gpt-bulk-delete-root";
    const shell = `
      <div class="gptbd-toolbar">
        <div class="gptbd-mode-tabs" role="tablist" aria-label="Bulk delete mode">
          <button type="button" class="gptbd-mode-tab" data-action="set-mode" data-mode="chats"
                  role="tab" aria-selected="true">Chats</button>
          <button type="button" class="gptbd-mode-tab" data-action="set-mode" data-mode="library"
                  role="tab" aria-selected="false">Library</button>
        </div>

        <div class="gptbd-delete-notice" data-role="delete-pacing-notice" role="status" hidden>
          <strong class="gptbd-delete-notice__title">Why is deletion slow?</strong>
          <span>ChatGPT limits how quickly files and chats can be deleted. We add short pauses to reduce interruptions. Large selections may take a few minutes.</span>
        </div>

        <!-- ── Main horizontal bar ── -->
        <div class="gptbd-bar" data-role="chats-bar">

          <!-- Identity + mode toggle -->
          <div class="gptbd-section gptbd-section--id">
            <div class="gptbd-mark" aria-hidden="true">
              <img class="gptbd-mark-img" src="${MARK_ICON_URL}" alt="" decoding="async" />
            </div>
            <button type="button" class="gptbd-btn gptbd-btn--toggle" data-action="toggle"
                    title="Show selection checkboxes in the ChatGPT sidebar" aria-pressed="false">
              <svg class="gptbd-icon" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <rect x="2" y="3" width="10" height="2" rx="1" fill="currentColor"/>
                <rect x="2" y="7" width="10" height="2" rx="1" fill="currentColor"/>
                <rect x="2" y="11" width="6" height="2" rx="1" fill="currentColor"/>
                <rect x="13" y="2" width="2" height="12" rx="1" fill="currentColor" opacity="0.35"/>
              </svg>
              <span data-role="toggle-label">Show sidebar checkboxes</span>
            </button>
          </div>

          <div class="gptbd-sep" aria-hidden="true"></div>

          <!-- Search + exact toggle -->
          <div class="gptbd-section gptbd-section--search">
            <div class="gptbd-search-wrap">
              <svg class="gptbd-search-icon" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <circle cx="6.5" cy="6.5" r="4" stroke="currentColor" stroke-width="1.5"/>
                <path d="M10 10L13.5 13.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
              </svg>
              <input type="text" class="gptbd-search" data-role="search"
                     placeholder="Filter chats…" spellcheck="false" autocomplete="off" />
              <button type="button" class="gptbd-search-clear" data-action="clear-search"
                      aria-label="Clear search" hidden title="Clear filter">
                <svg viewBox="0 0 12 12" fill="none" aria-hidden="true">
                  <path d="M2 2l8 8M10 2L2 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
              </button>
              <button type="button" class="gptbd-search-exact" data-action="toggle-exact"
                      title="Match whole words only" aria-label="Match whole words only">Exact</button>
            </div>
          </div>

          <div class="gptbd-sep" aria-hidden="true"></div>

          <!-- Sync -->
          <div class="gptbd-section gptbd-section--sync">
            <button type="button" class="gptbd-btn gptbd-btn--chip" data-action="sync-all"
                    title="Download full conversation list from ChatGPT API">
              <svg class="gptbd-icon gptbd-icon--sync" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M13.5 8A5.5 5.5 0 0 1 3 10.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                <path d="M2.5 8A5.5 5.5 0 0 1 13 5.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                <path d="M11 3l2 2.5L10.5 7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M5 13L3 10.5 5.5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              <span data-role="sync-label">Sync all</span>
            </button>
            <div class="gptbd-sync-meta">
              <span class="gptbd-meta-pill" data-role="cache-count" hidden></span>
              <button type="button" class="gptbd-cache-clear" data-action="clear-cache"
                      title="Clear local cache" aria-label="Clear local cache" hidden></button>
              <span class="gptbd-meta-dot" data-role="sync-dot" aria-hidden="true" hidden>·</span>
              <span class="gptbd-meta-text" data-role="last-sync" hidden></span>
            </div>
          </div>

          <div class="gptbd-sep" aria-hidden="true"></div>

          <!-- Count + destructive action -->
          <div class="gptbd-section gptbd-section--act">
            <span class="gptbd-count" data-role="count" aria-live="polite">0 selected</span>
            <button type="button" class="gptbd-btn gptbd-btn--delete" data-action="delete" disabled
                    title="Delete selected conversations (you will be asked to confirm)">
              <svg class="gptbd-icon" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M3 4h10M6 4V3h4v1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M4.5 4l.8 8.5a1 1 0 0 0 1 .9h3.4a1 1 0 0 0 1-.9L11.5 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
              </svg>
              <span data-role="delete-label">Delete</span>
            </button>
          </div>
        </div><!-- /.gptbd-bar -->

        <div class="gptbd-submeta" data-role="chats-submeta">
          <div class="gptbd-submeta-left">
            <span class="gptbd-meta-text">local-only</span>
            <span class="gptbd-meta-dot">·</span>
            <span class="gptbd-meta-text">delete is permanent</span>
            <span class="gptbd-meta-dot" data-role="review-dot" hidden>·</span>
            <span class="gptbd-review-pill" data-role="review-pill" hidden>
              <button type="button" class="gptbd-review-link" data-action="rate-extension">Rate extension</button>
              <button type="button" class="gptbd-review-dismiss" data-action="dismiss-review-prompt"
                      aria-label="Hide rating prompt" title="Hide rating prompt">&times;</button>
            </span>
            <span class="gptbd-meta-dot" data-role="match-meta-dot" hidden>·</span>
            <span class="gptbd-meta-text" data-role="match-count" hidden></span>
            <span class="gptbd-meta-dot" data-role="health-note-dot" hidden>·</span>
            <span class="gptbd-meta-text gptbd-meta-text--warning" data-role="health-note" hidden></span>
            <span class="gptbd-meta-dot" data-role="jump-hint-dot" hidden>·</span>
            <span class="gptbd-meta-text gptbd-meta-text--hint" data-role="jump-hint" hidden>
              Scroll the sidebar to select chats
            </span>
            <button type="button" class="gptbd-submeta-link gptbd-submeta-link--hint" data-action="jump-to-chats" hidden>
              Jump to chats
            </button>
          </div>
          <div class="gptbd-submeta-right">
            <span class="gptbd-meta-text" data-role="version-info"></span>
            <span class="gptbd-meta-dot" aria-hidden="true">·</span>
            <a class="gptbd-submeta-link" href="${DOC_LINKS.privacy}" target="_blank" rel="noopener noreferrer">Privacy</a>
            <span class="gptbd-meta-dot" aria-hidden="true">·</span>
            <a class="gptbd-submeta-link" href="${DOC_LINKS.license}" target="_blank" rel="noopener noreferrer">License</a>
            <span class="gptbd-meta-dot" aria-hidden="true">·</span>
            <a class="gptbd-submeta-link" href="${DOC_LINKS.terms}" target="_blank" rel="noopener noreferrer">Terms</a>
            <span class="gptbd-meta-dot" aria-hidden="true">·</span>
            <a class="gptbd-submeta-link" href="${DOC_LINKS.bugs}" target="_blank" rel="noopener noreferrer">Report bug</a>
            <span class="gptbd-meta-dot" aria-hidden="true">·</span>
            <button type="button" class="gptbd-submeta-toggle" data-action="toggle-ui-visibility"
                    title="Hide this toolbar"
                    aria-label="Hide this toolbar">Hide</button>
          </div>
        </div>

        <!-- Progress strip (delete / sync) -->
        <div class="gptbd-progress" data-role="chats-progress" data-visible="false" aria-hidden="true">
          <div class="gptbd-progress__track">
            <div class="gptbd-progress__bar" data-role="progress-bar"></div>
          </div>
          <span class="gptbd-progress__label" data-role="progress-label"></span>
        </div>

        <div class="gptbd-results-actions" data-role="chats-results-actions" data-visible="false">
          <div class="gptbd-results-actions__left" data-role="year-filters"></div>
          <div class="gptbd-results-actions__right">
            <button type="button" class="gptbd-results-action" data-action="toggle-results">
              Hide list
            </button>
            <button type="button" class="gptbd-results-action" data-action="toggle-sort"
                    title="Sort cached results by chat date">Newest first</button>
            <button type="button" class="gptbd-results-action" data-action="select-all"
                    disabled title="Select all current results, or all cached chats if no filter is active">All</button>
            <button type="button" class="gptbd-results-action" data-action="clear"
                    disabled title="Clear selection">Clear</button>
          </div>
        </div>

        <!-- Search-results panel (cached conversations) -->
        <div class="gptbd-results" data-role="chats-results" data-visible="false"></div>

        <section class="gptbd-library" data-role="library-panel" hidden aria-label="ChatGPT Library files">
          <div class="gptbd-library__bar">
            <div class="gptbd-search-wrap gptbd-library__search-wrap">
              <svg class="gptbd-search-icon" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <circle cx="6.5" cy="6.5" r="4" stroke="currentColor" stroke-width="1.5"/>
                <path d="M10 10L13.5 13.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
              </svg>
              <input type="text" class="gptbd-search" data-role="library-search" placeholder="Filter library files…" spellcheck="false" autocomplete="off" />
            </div>
            <button type="button" class="gptbd-btn gptbd-btn--chip" data-action="library-sync" data-testid="library-sync">
              <span data-role="library-sync-label">Sync Library</span>
            </button>
            <button type="button" class="gptbd-results-action" data-action="library-select-all" data-testid="library-select-all">Select all</button>
            <button type="button" class="gptbd-results-action" data-action="library-clear-selection">Clear</button>
            <button type="button" class="gptbd-results-action" data-action="library-clear-cache">Clear session</button>
        <button type="button" class="gptbd-btn gptbd-btn--delete" data-action="library-delete" data-testid="library-delete" disabled>
              <span data-role="library-delete-label">Remove files</span>
            </button>
          </div>
          <div class="gptbd-library__meta">
            <span class="gptbd-meta-text">Session only · thumbnails not saved by extension</span>
            <span class="gptbd-meta-dot" aria-hidden="true">·</span>
            <span class="gptbd-meta-text">All Library files · use this panel’s filter to narrow selection</span>
            <span class="gptbd-meta-dot" aria-hidden="true">·</span>
            <span data-role="library-count">0 files</span>
            <span class="gptbd-meta-dot" aria-hidden="true">·</span>
            <span data-role="library-selection-count">0 selected</span>
            <span class="gptbd-meta-dot" data-role="library-sync-dot" aria-hidden="true" hidden>·</span>
            <span data-role="library-last-sync" hidden></span>
            <span class="gptbd-meta-text gptbd-meta-text--warning" data-role="library-status" hidden></span>
          </div>
          <div class="gptbd-progress" data-role="library-progress" data-visible="false" aria-hidden="true">
            <div class="gptbd-progress__track"><div class="gptbd-progress__bar" data-role="library-progress-bar"></div></div>
            <span class="gptbd-progress__label" data-role="library-progress-label"></span>
          </div>
          <div class="gptbd-results gptbd-library__results" data-role="library-results" data-visible="true" data-testid="library-results"></div>
          <div class="gptbd-library__footer" data-role="library-footer" hidden>
            <button type="button" class="gptbd-results-action" data-action="library-show-more">Show more</button>
          </div>
        </section>

      </div><!-- /.gptbd-toolbar -->

      <!-- ── Confirmation modal ── -->
      <div class="gptbd-modal" id="gptbd-modal" data-visible="false"
           role="dialog" aria-modal="true" aria-labelledby="gptbd-modal-title">
        <button type="button" class="gptbd-modal__backdrop" data-action="modal-cancel"
                aria-label="Cancel and close dialog" tabindex="-1"></button>
        <div class="gptbd-modal__panel">
          <div class="gptbd-modal__header">
            <div class="gptbd-modal__icon-wrap" aria-hidden="true">
              <svg viewBox="0 0 20 20" fill="none" class="gptbd-modal__icon">
                <path d="M10 3L17.66 17H2.34L10 3Z" stroke="#ef4444" stroke-width="1.5" stroke-linejoin="round"/>
                <path d="M10 8v4" stroke="#ef4444" stroke-width="1.5" stroke-linecap="round"/>
                <circle cx="10" cy="14.5" r=".75" fill="#ef4444"/>
              </svg>
            </div>
            <div>
              <h2 class="gptbd-modal__title" id="gptbd-modal-title" data-role="modal-title">
                Delete conversations?
              </h2>
              <p class="gptbd-modal__subtitle">
                Permanent. ChatGPT does not support undo.
              </p>
            </div>
          </div>
          <div class="gptbd-modal__preview" data-role="modal-preview"></div>
          <div class="gptbd-modal__warning">
            <p class="gptbd-modal__warning-text">
              Delete is permanent and cannot be recovered.
            </p>
            <label class="gptbd-modal__check">
              <input type="checkbox" class="gptbd-modal__check-input" data-role="modal-warning-check" />
              <span class="gptbd-modal__check-label">I understand this delete is permanent and cannot be recovered.</span>
            </label>
            <label class="gptbd-modal__check">
              <input type="checkbox" class="gptbd-modal__check-input" data-role="modal-skip-warning-check" />
              <span class="gptbd-modal__check-label">Don't show me this warning again.</span>
            </label>
          </div>
          <div class="gptbd-modal__footer">
            <button type="button" class="gptbd-btn gptbd-btn--cancel" data-action="modal-cancel">
              Cancel
            </button>
            <button type="button" class="gptbd-btn gptbd-btn--delete-confirm" data-action="modal-confirm">
              <span data-role="modal-confirm-label">Delete</span>
            </button>
          </div>
        </div>
      </div><!-- /.gptbd-modal -->

      <!-- Toast -->
      <div class="gptbd-toast" aria-live="polite" aria-atomic="true"></div>
    `;
    root.append(createTemplateFragment(shell));

    document.documentElement.appendChild(root);

    /* ── Event delegation ── */
    root.addEventListener("click", async (event) => {
      const el = event.target.closest("[data-action]");
      if (!el) return;
      const action = el.dataset.action;

      if (action === "set-mode") {
        const nextMode = el.dataset.mode === "library" ? "library" : "chats";
        if (STATE.deleting || STATE.library.deletePending) {
          showToast("Finish or cancel the current deletion before switching tabs.");
          return;
        }
        if (STATE.syncingAll || STATE.library.syncing) {
          showToast("Still loading your list. You can switch tabs when loading finishes.");
          return;
        }
        // A deliberate tab choice takes precedence over a deferred route update.
        observedRoutePath = window.location.pathname;
        STATE.mode = nextMode;
        void setToolbarModePreference(nextMode);
        if (nextMode === "library") {
          STATE.enabled = false;
          STATE.selectedIds.clear();
          STATE.lastSelectedId = null;
          refreshConversationRows();
          void ensureLibraryCacheForCurrentAccount();
        }
        render();
        return;
      }

      if (action === "library-sync") {
        await syncLibraryFiles();
        return;
      }

      if (action === "library-select-all") {
        getFilteredLibraryFiles().forEach(file => STATE.library.selectedIds.add(file.id));
        render();
        return;
      }

      if (action === "library-clear-selection") {
        STATE.library.selectedIds.clear();
        render();
        return;
      }

      if (action === "library-clear-cache") {
        if (STATE.library.syncing || STATE.deleting) return;
        revokeLibraryThumbnails();
        GPTBDLibraryUi?.clearCache?.(STATE.library, window.localStorage);
        render();
        showToast("Library files and thumbnails were cleared from this browser session.");
        return;
      }

      if (action === "library-show-more") {
        if (STATE.library.syncing || STATE.deleting) return;
        STATE.library.visibleLimit += 50;
        render();
        return;
      }

      if (action === "library-delete") {
        await deleteSelectedLibraryFiles();
        return;
      }

      if (action === "toggle") {
        if (STATE.library.deletePending) return;
        const wasEnabled = STATE.enabled;
        STATE.enabled = !STATE.enabled;
        if (!STATE.enabled) {
          STATE.selectedIds.clear();
          STATE.lastSelectedId = null;
        } else if (getPageContext().mode === "project") {
          STATE.resultsCollapsed = false;
        }
        refreshConversationRows();
        render();
        if (!wasEnabled && STATE.enabled && getPageContext().mode !== "project") {
          if (!hasVisibleSidebarConversationRow()) {
            showToast("Checkboxes are enabled. Open the ChatGPT sidebar to select chats.");
          }
          window.setTimeout(() => {
            jumpToFirstConversationRow();
          }, 80);
        }
        return;
      }

      if (action === "select-scope") {
        return;
      }

      if (action === "select-project-filter") {
        return;
      }

      if (action === "sync-all") {
        await syncAllChats();
        return;
      }

      if (action === "toggle-exact") {
        STATE.exactSearch = !STATE.exactSearch;
        refreshConversationRows();
        render();
        return;
      }

      if (action === "clear-search") {
        STATE.searchTerm = "";
        const searchInput = root.querySelector('[data-role="search"]');
        if (searchInput) searchInput.value = "";
        refreshConversationRows();
        render();
        return;
      }

      if (action === "select-all") {
        selectAllRows();
        render();
        return;
      }

      if (action === "jump-to-chats") {
        jumpToFirstConversationRow();
        render();
        return;
      }

      if (action === "clear") {
        STATE.selectedIds.clear();
        STATE.lastSelectedId = null;
        syncCheckboxes();
        render();
        return;
      }

      if (action === "toggle-sort") {
        STATE.cachedSortOrder = STATE.cachedSortOrder === "newest" ? "oldest" : "newest";
        render();
        return;
      }

      if (action === "toggle-results") {
        STATE.resultsCollapsed = !STATE.resultsCollapsed;
        render();
        return;
      }

      if (action === "filter-year") {
        STATE.selectedYear = el.dataset.year || "all";
        render();
        return;
      }

      if (action === "clear-cache") {
        const confirmed = await showClearCacheModal();
        if (!confirmed) return;
        clearLocalCache();
        refreshConversationRows();
        render();
        showToast("Local cache cleared.");
        return;
      }

      if (action === "delete") {
        await deleteSelectedConversations();
        return;
      }

      if (action === "toggle-ui-visibility") {
        await setUiHiddenPreference(!STATE.uiHidden);
        return;
      }

      if (action === "rate-extension") {
        window.open(getReviewUrl(), "_blank", "noopener,noreferrer");
        void hideReviewPrompt();
        return;
      }

      if (action === "dismiss-review-prompt") {
        await hideReviewPrompt();
        return;
      }

      if (action === "modal-cancel") {
        if (activeModalResolve) activeModalResolve(false);
        return;
      }

      if (action === "modal-confirm") {
        if (activeModalResolve) activeModalResolve(true);
        return;
      }
    });

    /* ── Search input ── */
    const searchInput = root.querySelector('[data-role="search"]');
    searchInput.addEventListener("input", (event) => {
      if (STATE.mode !== "chats") return;
      STATE.searchTerm = normalizeSearchTerm(event.target.value);
      if (STATE.searchTerm) STATE.resultsCollapsed = false;
      refreshConversationRows();
      render();
    });

    const librarySearchInput = root.querySelector('[data-role="library-search"]');
    librarySearchInput?.addEventListener("input", event => {
      STATE.library.searchTerm = normalizeSearchTerm(event.target.value);
      render();
    });

    root.addEventListener("change", event => {
      const scopeSelect = event.target.closest('[data-action="select-scope"]');
      if (!scopeSelect) return;
      STATE.resultScope = scopeSelect.value === "account" ? "account" : "project";
      STATE.selectedProjectKey = "all";
      STATE.selectedIds.clear();
      STATE.lastSelectedId = null;
      STATE.resultsCollapsed = false;
      refreshConversationRows();
      render();
    });

    root.addEventListener("change", event => {
      const projectSelect = event.target.closest('[data-action="select-project-filter"]');
      if (!projectSelect) return;
      STATE.selectedProjectKey = projectSelect.value || "all";
      STATE.selectedIds.clear();
      STATE.lastSelectedId = null;
      STATE.resultsCollapsed = false;
      refreshConversationRows();
      render();
    });

    /* ── Keyboard: Escape exits select mode / closes modal ── */
    document.addEventListener("keydown", (event) => {
      if (event.key !== "Escape") return;
      if (activeModalResolve) return; // modal handles its own Escape
      if (STATE.enabled && !STATE.deleting && !STATE.syncingAll) {
        STATE.enabled = false;
        STATE.selectedIds.clear();
        STATE.lastSelectedId = null;
        refreshConversationRows();
        render();
      }
    });

    document.addEventListener("pointerdown", (event) => {
      if (!(event.target instanceof Node)) return;
      if (shouldAutoCollapseResults(event.target)) {
        STATE.resultsCollapsed = true;
        render();
      }
    }, true);

    render();
  }

  /* ───────────────────────────── DOM OBSERVER ───────────────────────────── */
  function observeDom() {
    if (STATE.observer) return;
    STATE.observer = new MutationObserver(() => {
      window.clearTimeout(STATE.refreshTimer);
      STATE.refreshTimer = window.setTimeout(() => {
        applyLibraryRouteMode();
        refreshConversationRows();
        void ensureCapabilityHealth({ force: false, silent: true });
        render();
      }, 150);
    });
    STATE.observer.observe(document.body, { childList: true, subtree: true });
  }

  /* ──────────────────────────────── RENDER ──────────────────────────────── */
  function render() {
    const toolbar = document.querySelector(".gptbd-toolbar");
    const root = document.getElementById("gpt-bulk-delete-root");
    if (!toolbar || !root) return;

    toolbar.hidden = STATE.uiHidden;
    if (STATE.uiHidden) return;

    const deletionNotice = toolbar.querySelector('[data-role="delete-pacing-notice"]');
    if (deletionNotice) deletionNotice.hidden = !STATE.deleting;
    const libraryActive = STATE.mode === "library";
    toolbar.querySelectorAll("[data-role='chats-bar'], [data-role='chats-submeta'], [data-role='chats-progress'], [data-role='chats-results-actions'], [data-role='chats-results']")
      .forEach(element => { element.hidden = libraryActive; });
    toolbar.querySelectorAll("[data-action='set-mode']").forEach(tab => {
      const active = tab.dataset.mode === STATE.mode;
      tab.dataset.active = String(active);
      tab.setAttribute("aria-selected", String(active));
    });
    const libraryPanel = toolbar.querySelector('[data-role="library-panel"]');
    if (libraryPanel) libraryPanel.hidden = !libraryActive;
    if (libraryActive) {
      renderLibraryPanel(toolbar);
      return;
    }

    const pageContext = getPageContext();
    const activeScope = getEffectiveResultScope(pageContext);
    const projectMode = activeScope === "project";
    const selectedCount = STATE.selectedIds.size;
    const matchCount = getSearchResults().length;
    const hasCache = STATE.cachedConversations.length > 0;
    const busy = STATE.deleting || STATE.syncingAll || STATE.library.deletePending;
    const health = STATE.health;
    const deleteCoolingDown = isDeleteCoolingDown();
    const hasVisibleSidebar = hasVisibleSidebarConversationRow();

    /* Toggle button */
    const toggleLabel = toolbar.querySelector('[data-role="toggle-label"]');
    const toggleBtn = toolbar.querySelector('[data-action="toggle"]');
    const toggleCopy = GPTBDUi.getSelectionToggleCopy({
      enabled: STATE.enabled,
      projectMode,
      hasVisibleSidebar
    });
    if (toggleLabel) toggleLabel.textContent = toggleCopy.label;
    if (toggleBtn) {
      toggleBtn.disabled = busy;
      toggleBtn.dataset.active = String(STATE.enabled);
      toggleBtn.title = toggleCopy.title;
      toggleBtn.setAttribute("aria-label", toggleCopy.title);
      toggleBtn.setAttribute("aria-pressed", String(STATE.enabled));
    }

    /* Sync button */
    const syncBtn = toolbar.querySelector('[data-action="sync-all"]');
    const syncLabel = toolbar.querySelector('[data-role="sync-label"]');
    if (syncLabel) {
      syncLabel.textContent = STATE.syncingAll
        ? "Syncing…"
        : health.syncAvailable ? (hasCache ? "Resync" : "Sync all") : "Sync unavailable";
    }
    if (syncBtn) {
      syncBtn.disabled = busy || !health.syncAvailable;
      syncBtn.dataset.spinning = String(STATE.syncingAll);
      syncBtn.title = health.syncAvailable
        ? "Download full conversation list from ChatGPT API"
        : "Sync is temporarily unavailable until compatibility checks pass";
    }

    /* Sync meta */
    const cacheCountEl = toolbar.querySelector('[data-role="cache-count"]');
    const clearCacheBtn = toolbar.querySelector('[data-action="clear-cache"]');
    const syncDotEl = toolbar.querySelector('[data-role="sync-dot"]');
    const lastSyncEl = toolbar.querySelector('[data-role="last-sync"]');
    if (cacheCountEl) {
      cacheCountEl.textContent = hasCache ? `${STATE.cachedConversations.length.toLocaleString()} cached` : "";
      cacheCountEl.hidden = !hasCache;
    }
    if (clearCacheBtn) {
      clearCacheBtn.hidden = !hasCache;
      clearCacheBtn.disabled = busy;
    }
    if (lastSyncEl) {
      const syncedText = STATE.cacheLoadedAt ? formatLastSync(STATE.cacheLoadedAt) : "";
      lastSyncEl.textContent = syncedText;
      lastSyncEl.hidden = !syncedText;
    }
    if (syncDotEl) syncDotEl.hidden = !(hasCache && STATE.cacheLoadedAt);

    const versionInfoEl = toolbar.querySelector('[data-role="version-info"]');
    if (versionInfoEl) versionInfoEl.textContent = `v${APP_VERSION}`;

    const reviewDotEl = toolbar.querySelector('[data-role="review-dot"]');
    const reviewPillEl = toolbar.querySelector('[data-role="review-pill"]');
    const shouldShowReview = shouldShowReviewPrompt();
    if (reviewDotEl) reviewDotEl.hidden = !shouldShowReview;
    if (reviewPillEl) reviewPillEl.hidden = !shouldShowReview;

    const uiToggleBtn = toolbar.querySelector('[data-action="toggle-ui-visibility"]');
    if (uiToggleBtn) {
      uiToggleBtn.textContent = STATE.uiHidden ? "Show" : "Hide";
      uiToggleBtn.title = STATE.uiHidden ? "Show this toolbar" : "Hide this toolbar";
      uiToggleBtn.setAttribute("aria-label", uiToggleBtn.title);
      uiToggleBtn.disabled = busy;
    }

    /* Search */
    const searchInput = toolbar.querySelector('[data-role="search"]');
    const clearSearchBtn = toolbar.querySelector('[data-action="clear-search"]');
    const exactBtn = toolbar.querySelector('[data-action="toggle-exact"]');
    const matchCountEl = toolbar.querySelector('[data-role="match-count"]');
    const matchMetaDotEl = toolbar.querySelector('[data-role="match-meta-dot"]');
    const jumpHintDotEl = toolbar.querySelector('[data-role="jump-hint-dot"]');
    const jumpHintEl = toolbar.querySelector('[data-role="jump-hint"]');
    const jumpHintBtn = toolbar.querySelector('[data-action="jump-to-chats"]');
    if (searchInput) {
      searchInput.disabled = busy;
      searchInput.placeholder = projectMode ? "Filter project chats…" : "Filter chats…";
    }
    if (clearSearchBtn) clearSearchBtn.hidden = !STATE.searchTerm;
    if (exactBtn) {
      exactBtn.disabled = busy;
      exactBtn.dataset.active = String(STATE.exactSearch);
    }
    if (matchCountEl) {
      const hasSearch = Boolean(STATE.searchTerm);
      const hasYearFilter = STATE.selectedYear !== "all";
      const hasProjectFilter = !projectMode && STATE.selectedProjectKey !== "all";
      if (projectMode) {
        matchCountEl.textContent = hasSearch
          ? `${matchCount} project match${matchCount === 1 ? "" : "es"}`
          : `${matchCount} project chat${matchCount === 1 ? "" : "s"} shown`;
      } else if (hasSearch || hasYearFilter || hasProjectFilter) {
        const parts = [`${matchCount} match${matchCount === 1 ? "" : "es"}`];
        if (hasYearFilter) parts.push(`year ${STATE.selectedYear}`);
        if (hasProjectFilter) parts.push(getProjectFilterLabel(STATE.selectedProjectKey));
        matchCountEl.textContent = parts.join(" in ");
      } else {
        matchCountEl.textContent = "";
      }
      matchCountEl.hidden = !(projectMode || hasSearch || hasYearFilter || hasProjectFilter);
    }
    if (matchMetaDotEl) {
      matchMetaDotEl.hidden = !(projectMode || STATE.searchTerm || STATE.selectedYear !== "all" || STATE.selectedProjectKey !== "all");
    }

    const healthNoteEl = toolbar.querySelector('[data-role="health-note"]');
    const healthNoteDotEl = toolbar.querySelector('[data-role="health-note-dot"]');
    if (healthNoteEl) {
      healthNoteEl.textContent = health.note || "";
      healthNoteEl.hidden = !health.note;
    }
    if (healthNoteDotEl) healthNoteDotEl.hidden = !health.note;

    const sidebarNeedsOpening = STATE.enabled && !projectMode && !hasVisibleSidebar;
    const shouldShowJumpHint = STATE.enabled && !busy && (sidebarNeedsOpening || needsJumpToChatsHint());
    if (jumpHintEl) {
      jumpHintEl.textContent = sidebarNeedsOpening
        ? "Open the ChatGPT sidebar to use checkboxes"
        : "Scroll the sidebar to select chats";
    }
    if (jumpHintDotEl) jumpHintDotEl.hidden = !shouldShowJumpHint;
    if (jumpHintEl) jumpHintEl.hidden = !shouldShowJumpHint;
    if (jumpHintBtn) jumpHintBtn.hidden = !shouldShowJumpHint || sidebarNeedsOpening;

    /* Selection buttons */
    const selectAllBtn = toolbar.querySelector('[data-action="select-all"]');
    const clearBtn = toolbar.querySelector('[data-action="clear"]');
    const sortBtn = toolbar.querySelector('[data-action="toggle-sort"]');
    const toggleResultsBtn = toolbar.querySelector('[data-action="toggle-results"]');
    const resultsActions = toolbar.querySelector(".gptbd-results-actions");
    const yearFiltersHost = toolbar.querySelector('[data-role="year-filters"]');
    const selectableCount = getSelectableConversationIds().length;
    const showingCachedResults = !projectMode && STATE.cachedConversations.length > 0;
    const showingProjectActions = projectMode;
    if (selectAllBtn) selectAllBtn.disabled = busy || selectableCount === 0 || !canDeleteSelection(getSelectableConversationIds());
    if (selectAllBtn) {
      selectAllBtn.textContent = projectMode ? (STATE.searchTerm ? "All matches" : "All shown") : "All";
      selectAllBtn.title = projectMode
        ? STATE.searchTerm
          ? "Select all matching project chats"
          : "Select all currently shown project chats"
        : "Select all current results, or all cached chats if no filter is active";
    }
    if (clearBtn) clearBtn.disabled = selectedCount === 0 || busy;
    if (sortBtn) {
      sortBtn.hidden = projectMode;
      sortBtn.disabled = busy || !showingCachedResults;
      sortBtn.textContent = STATE.cachedSortOrder === "newest" ? "Sort: Newest ↓" : "Sort: Oldest ↑";
      sortBtn.title = STATE.cachedSortOrder === "newest"
        ? "Sorting by newest first. Click to switch to oldest first."
        : "Sorting by oldest first. Click to switch to newest first.";
    }
    if (toggleResultsBtn) {
      toggleResultsBtn.hidden = false;
      toggleResultsBtn.disabled = busy || (projectMode ? selectableCount === 0 : !showingCachedResults);
      toggleResultsBtn.textContent = projectMode
        ? STATE.resultsCollapsed ? "Show project list" : "Hide project list"
        : STATE.resultsCollapsed ? "Show list" : "Hide list";
      toggleResultsBtn.title = projectMode
        ? "Show or hide the discovered project chat list"
        : "Show or hide the cached results list";
    }
    if (resultsActions) {
      resultsActions.dataset.visible = String(showingCachedResults || showingProjectActions);
    }
    if (yearFiltersHost) {
      replaceChildren(yearFiltersHost, buildFilterControls({
        pageContext,
        activeScope,
        hasCache,
        showingCachedResults
      }));
    }

    /* Count */
    const countEl = toolbar.querySelector('[data-role="count"]');
    if (countEl) {
      countEl.textContent = `${selectedCount} selected`;
      countEl.dataset.hasSelection = String(selectedCount > 0);
    }

    /* Delete button */
    const deleteBtn = toolbar.querySelector('[data-action="delete"]');
    const deleteLabelEl = toolbar.querySelector('[data-role="delete-label"]');
    if (deleteBtn) {
      deleteBtn.disabled = selectedCount === 0 || busy || deleteCoolingDown || !canDeleteSelection();
      deleteBtn.title = deleteCoolingDown
        ? formatDeleteCooldownMessage()
        : canDeleteSelection()
        ? projectMode
          ? "Delete selected project conversations permanently (you will be asked to confirm)"
          : "Delete selected conversations (you will be asked to confirm)"
        : "Delete is temporarily unavailable until compatibility checks pass";
    }
    if (deleteLabelEl) {
      if (STATE.deleting) {
        deleteLabelEl.textContent = `Deleting ${STATE.deleteProgress.current}\u2009/\u2009${STATE.deleteProgress.total}`;
      } else {
        deleteLabelEl.textContent = selectedCount > 0 ? `Delete\u00a0${selectedCount}` : "Delete";
      }
    }

    /* Progress strip */
    const progressWrap = toolbar.querySelector(".gptbd-progress");
    const progressBar = toolbar.querySelector('[data-role="progress-bar"]');
    const progressLabel = toolbar.querySelector('[data-role="progress-label"]');
    if (progressWrap && progressBar) {
      if (STATE.deleting) {
        progressWrap.dataset.visible = "true";
        progressWrap.dataset.indeterminate = "false";
        const pct = STATE.deleteProgress.total > 0
          ? (STATE.deleteProgress.current / STATE.deleteProgress.total) * 100
          : 0;
        progressBar.style.width = `${pct}%`;
        if (progressLabel) progressLabel.textContent =
          `${STATE.deleteProgress.current} of ${STATE.deleteProgress.total} processed`;
      } else if (STATE.syncingAll) {
        progressWrap.dataset.visible = "true";
        progressWrap.dataset.indeterminate = "true";
        progressBar.style.width = "0%";
        if (progressLabel) progressLabel.textContent = "Fetching conversation list…";
      } else {
        progressWrap.dataset.visible = "false";
        progressWrap.dataset.indeterminate = "false";
        progressBar.style.width = "0%";
        if (progressLabel) progressLabel.textContent = "";
      }
    }

    renderResultsPanel(toolbar.querySelector(".gptbd-results"));
  }

  /* ───────────────────────────── LIBRARY MODE ──────────────────────────── */
  async function ensureLibraryCacheForCurrentAccount() {
    const session = await getSessionContext();
    if (session?.accountKey && STATE.library.accountKey !== session.accountKey) {
      revokeLibraryThumbnails();
      GPTBDLibraryUi?.loadCache?.(STATE.library, window.localStorage, session.accountKey);
    }
    if (session?.accountKey && STATE.mode === "library" && !STATE.uiHidden) {
      void maybeAutoSyncLibrary(session);
    }
    render();
  }

  async function maybeAutoSyncLibrary(session) {
    if (!session?.accountKey || STATE.library.syncing || STATE.deleting) return;
    if (libraryAutoSyncAttempts.has(session.accountKey)) return;
    libraryAutoSyncAttempts.add(session.accountKey);
    await syncLibraryFiles({ automatic: true, sessionHint: session });
  }

  function getFilteredLibraryFiles() {
    const filter = GPTBDLibraryUi?.filterFiles;
    return filter
      ? filter(STATE.library.files, STATE.library.searchTerm)
      : STATE.library.files.filter(file => !STATE.library.searchTerm || String(file.title || file.fileName || "").toLowerCase().includes(STATE.library.searchTerm));
  }

  function renderLibraryPanel(toolbar) {
    const library = STATE.library;
    const busy = Boolean(library.syncing || STATE.deleting || library.deletePending);
    const files = getFilteredLibraryFiles();
    const syncButton = toolbar.querySelector('[data-action="library-sync"]');
    const syncLabel = toolbar.querySelector('[data-role="library-sync-label"]');
    const search = toolbar.querySelector('[data-role="library-search"]');
    const selectAll = toolbar.querySelector('[data-action="library-select-all"]');
    const clear = toolbar.querySelector('[data-action="library-clear-selection"]');
    const clearSession = toolbar.querySelector('[data-action="library-clear-cache"]');
    const remove = toolbar.querySelector('[data-action="library-delete"]');
    const removeLabel = toolbar.querySelector('[data-role="library-delete-label"]');
    const results = toolbar.querySelector('[data-role="library-results"]');
    const count = toolbar.querySelector('[data-role="library-count"]');
    const selected = toolbar.querySelector('[data-role="library-selection-count"]');
    const syncDot = toolbar.querySelector('[data-role="library-sync-dot"]');
    const lastSync = toolbar.querySelector('[data-role="library-last-sync"]');
    const status = toolbar.querySelector('[data-role="library-status"]');
    const progress = toolbar.querySelector('[data-role="library-progress"]');
    const progressBar = toolbar.querySelector('[data-role="library-progress-bar"]');
    const progressLabel = toolbar.querySelector('[data-role="library-progress-label"]');
    const footer = toolbar.querySelector('[data-role="library-footer"]');
    const showMore = toolbar.querySelector('[data-action="library-show-more"]');
    const hasCore = Boolean(globalThis.GPTBDLibrary?.fetchLibraryFiles && globalThis.GPTBDLibrary?.deleteLibraryFile);
    const coolingDown = isDeleteCoolingDown(library.accountKey || STATE.accountKey);

    if (syncLabel) syncLabel.textContent = library.syncing ? "Syncing…" : (library.files.length || library.lastError) ? "Resync Library" : "Sync Library";
    if (syncButton) {
      syncButton.disabled = busy || !hasCore;
      syncButton.title = hasCore ? "Download your ChatGPT Library file list" : "Library module is unavailable. Reload the extension, then refresh ChatGPT.";
    }
    if (search) search.disabled = STATE.deleting;
    if (count) count.textContent = `${library.files.length.toLocaleString()} file${library.files.length === 1 ? "" : "s"}`;
    if (selected) selected.textContent = `${library.selectedIds.size} selected`;
    if (syncDot) syncDot.hidden = !library.cacheLoadedAt;
    if (lastSync) {
      lastSync.textContent = library.cacheLoadedAt ? `synced ${formatLastSync(library.cacheLoadedAt)}` : "";
      lastSync.hidden = !library.cacheLoadedAt;
    }
    if (status) {
      const message = coolingDown
        ? formatDeleteCooldownMessage()
        : library.lastError
          ? `${library.lastError} Use Resync Library to retry.`
        : !hasCore
        ? "Library module is unavailable. Reload the extension, then refresh ChatGPT."
        : library.deleteApiAvailable === false
          ? "Library delete API unavailable. No files can be deleted."
          : library.deleteApiAvailable === null
            ? "Library deletion has not been tested in this session yet."
            : "";
      status.textContent = message;
      status.hidden = !message;
    }
    if (selectAll) {
      selectAll.disabled = busy || files.length === 0;
      selectAll.textContent = files.length ? `Select all ${files.length.toLocaleString()}` : "Select all";
      selectAll.title = files.length ? `Select all ${files.length.toLocaleString()} filtered files, including files not shown yet` : "No filtered files to select";
    }
    if (clear) clear.disabled = busy || library.selectedIds.size === 0;
    if (clearSession) clearSession.disabled = busy || library.files.length === 0;
    if (remove) {
      remove.disabled = busy || !library.isComplete || coolingDown || library.selectedIds.size === 0 || !hasCore || library.deleteApiAvailable === false;
      remove.title = coolingDown
        ? formatDeleteCooldownMessage()
        : "Remove selected Library files after confirmation";
    }
    if (removeLabel) {
      removeLabel.textContent = STATE.deleting
        ? `Removing ${STATE.deleteProgress.current}/${STATE.deleteProgress.total}`
        : library.selectedIds.size ? `Remove ${library.selectedIds.size} files` : "Remove files";
    }
    if (progress && progressBar) {
      if (library.syncing) {
        progress.dataset.visible = "true";
        progress.dataset.indeterminate = "true";
        progressBar.style.width = "0%";
        if (progressLabel) {
          const fetched = Number(library.syncProgress) || 0;
          progressLabel.textContent = fetched ? `Fetched ${fetched.toLocaleString()} Library files…` : "Fetching Library files…";
        }
      } else if (STATE.deleting) {
        progress.dataset.visible = "true";
        progress.dataset.indeterminate = "false";
        const pct = STATE.deleteProgress.total ? (STATE.deleteProgress.current / STATE.deleteProgress.total) * 100 : 0;
        progressBar.style.width = `${pct}%`;
        if (progressLabel) progressLabel.textContent = `${STATE.deleteProgress.current} of ${STATE.deleteProgress.total} processed`;
      } else {
        progress.dataset.visible = "false";
        progress.dataset.indeterminate = "false";
        progressBar.style.width = "0%";
      }
    }
    const remaining = Math.max(0, files.length - library.visibleLimit);
    if (footer) footer.hidden = remaining === 0;
    if (showMore) {
      showMore.disabled = STATE.deleting;
      showMore.textContent = `Show 50 more (${remaining.toLocaleString()} remaining)`;
    }
    renderLibraryResults(results, files);
  }

  function renderLibraryResults(panel, files) {
    if (!panel) return;
    if (STATE.library.syncing && STATE.library.files.length === 0) {
      delete panel.dataset.libraryRenderKey;
      replaceChildren(panel, [buildEmptyState("Fetching Library files…", "notice")]);
      return;
    }
    if (!STATE.library.accountKey) {
      delete panel.dataset.libraryRenderKey;
      replaceChildren(panel, [buildEmptyState("Open ChatGPT while signed in, then sync your Library.", "notice")]);
      return;
    }
    if (STATE.library.files.length === 0) {
      delete panel.dataset.libraryRenderKey;
      replaceChildren(panel, [buildEmptyState("No Library files are loaded for this browser session. Click Sync Library to load them.", "notice")]);
      return;
    }
    if (files.length === 0) {
      delete panel.dataset.libraryRenderKey;
      replaceChildren(panel, [buildEmptyState("No Library files match this filter.")]);
      return;
    }
    const visibleFiles = files.slice(0, STATE.library.visibleLimit);
    const renderKey = `${STATE.library.renderRevision || 0}:${visibleFiles.map(file => file.id).join("|")}`;
    if (panel.dataset.libraryRenderKey !== renderKey) {
      const grid = document.createElement("div");
      grid.className = "gptbd-library-grid";
      grid.dataset.role = "library-grid";
      visibleFiles.forEach(file => grid.appendChild(buildLibraryTile(file)));
      replaceChildren(panel, [grid]);
      panel.dataset.libraryRenderKey = renderKey;
      observeLibraryThumbnails(grid);
    }
    panel.querySelectorAll("[data-library-id]").forEach(checkbox => {
      const id = checkbox.dataset.libraryId;
      checkbox.checked = STATE.library.selectedIds.has(id);
      checkbox.disabled = STATE.library.syncing || STATE.deleting;
    });
  }

  function buildLibraryTile(file) {
    const tile = document.createElement("label");
    tile.className = "gptbd-library-tile";
    tile.dataset.libraryId = file.id;
    const preview = document.createElement("span");
    preview.className = "gptbd-library-tile__preview";
    const image = document.createElement("img");
    image.className = "gptbd-library-tile__image";
    image.alt = "";
    image.decoding = "async";
    image.dataset.libraryThumbnailId = file.id;
    if (libraryThumbnailUrls.has(file.id)) image.src = libraryThumbnailUrls.get(file.id);
    const fallback = document.createElement("span");
    fallback.className = "gptbd-library-tile__fallback";
    fallback.textContent = getLibraryFileKind(file);
    preview.append(image, fallback);

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "gptbd-result-checkbox gptbd-library-tile__checkbox";
    checkbox.dataset.libraryId = file.id;
    checkbox.checked = STATE.library.selectedIds.has(file.id);
    checkbox.disabled = STATE.library.syncing || STATE.deleting;
    checkbox.addEventListener("change", event => {
      if (event.target.checked) STATE.library.selectedIds.add(file.id);
      else STATE.library.selectedIds.delete(file.id);
      render();
    });
    const title = document.createElement("span");
    title.className = "gptbd-library-tile__title";
    title.textContent = file.title || file.fileName || "Unnamed file";
    title.title = title.textContent;
    const meta = document.createElement("span");
    meta.className = "gptbd-library-tile__meta";
    meta.textContent = formatConversationDate(file.createdAt);
    tile.append(preview, checkbox, title, meta);
    return tile;
  }

  function getLibraryFileKind(file) {
    const mime = String(file.mimeType || "").toLowerCase();
    if (mime.startsWith("image/")) return "Image";
    if (mime.includes("pdf")) return "PDF";
    const extension = String(file.fileName || file.title || "").split(".").pop();
    return extension && extension !== file.fileName ? extension.toUpperCase().slice(0, 8) : "File";
  }

  function observeLibraryThumbnails(grid) {
    if (libraryThumbnailObserver) libraryThumbnailObserver.disconnect();
    const images = Array.from(grid.querySelectorAll("[data-library-thumbnail-id]"));
    if (typeof IntersectionObserver !== "function") {
      images.slice(0, 12).forEach(image => queueLibraryThumbnail(image));
      return;
    }
    libraryThumbnailObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        libraryThumbnailObserver?.unobserve(entry.target);
        queueLibraryThumbnail(entry.target);
      });
    }, { root: null, rootMargin: "240px 0px" });
    images.forEach(image => libraryThumbnailObserver.observe(image));
  }

  function queueLibraryThumbnail(image) {
    const id = image?.dataset?.libraryThumbnailId;
    if (!id || libraryThumbnailUrls.has(id) || libraryThumbnailLoading.has(id)) return;
    const file = STATE.library.files.find(item => item.id === id);
    if (!file || !getLibraryThumbnailUrl(file)) return;
    const generation = libraryThumbnailGeneration;
    libraryThumbnailLoading.set(id, generation);
    libraryThumbnailQueue.push({ id, image, file, generation });
    drainLibraryThumbnailQueue();
  }

  function drainLibraryThumbnailQueue() {
    while (libraryThumbnailActive < LIBRARY_THUMBNAIL_CONCURRENCY && libraryThumbnailQueue.length) {
      const item = libraryThumbnailQueue.shift();
      if (!item?.image?.isConnected || item.generation !== libraryThumbnailGeneration || STATE.library.files.every(file => file.id !== item.id)) {
        if (libraryThumbnailLoading.get(item?.id) === item?.generation) libraryThumbnailLoading.delete(item?.id);
        continue;
      }
      libraryThumbnailActive += 1;
      void fetchLibraryThumbnail(item).finally(() => {
        libraryThumbnailActive -= 1;
        if (libraryThumbnailLoading.get(item.id) === item.generation) libraryThumbnailLoading.delete(item.id);
        if (item.generation !== libraryThumbnailGeneration) {
          const replacement = document.querySelector(`[data-library-thumbnail-id="${CSS.escape(item.id)}"]`);
          if (replacement) queueLibraryThumbnail(replacement);
        }
        drainLibraryThumbnailQueue();
      });
    }
  }

  async function fetchLibraryThumbnail({ id, image, file, generation }) {
    const url = getLibraryThumbnailUrl(file);
    if (!url) return;
    const controller = new AbortController();
    libraryThumbnailControllers.set(id, { controller, generation });
    const timeoutId = window.setTimeout(() => controller.abort(), 15 * 1000);
    try {
      const response = await fetch(url, {
        credentials: "include",
        cache: "no-store",
        redirect: "follow",
        mode: "same-origin",
        referrerPolicy: "no-referrer",
        signal: controller.signal
      });
      if (!response.ok) throw new Error("thumbnail unavailable");
      const contentLength = Number(response.headers.get("content-length"));
      if (Number.isFinite(contentLength) && contentLength > 5 * 1024 * 1024) throw new Error("thumbnail too large");
      const blob = await response.blob();
      if (blob.size > 5 * 1024 * 1024) throw new Error("thumbnail too large");
      if (!blob.type.startsWith("image/")) throw new Error("thumbnail was not an image");
      if (controller.signal.aborted || generation !== libraryThumbnailGeneration || STATE.library.files.every(current => current.id !== id)) return;
      const objectUrl = URL.createObjectURL(blob);
      libraryThumbnailUrls.set(id, objectUrl);
      document.querySelectorAll(`[data-library-thumbnail-id="${CSS.escape(id)}"]`).forEach(element => {
        if (element instanceof HTMLImageElement) element.src = objectUrl;
      });
    } catch (_) {
      image.closest(".gptbd-library-tile")?.setAttribute("data-thumbnail-failed", "true");
    } finally {
      window.clearTimeout(timeoutId);
      if (libraryThumbnailControllers.get(id)?.controller === controller) libraryThumbnailControllers.delete(id);
    }
  }

  function getLibraryThumbnailUrl(file) {
    if (typeof file?.thumbnailUrl !== "string" || !file.thumbnailUrl) return null;
    try {
      const url = new URL(file.thumbnailUrl, window.location.origin);
      const isThumbnailPath = url.pathname === LIBRARY_THUMBNAIL_PATH
        || /^\/library\/files\/[A-Za-z0-9_-]+\/thumbnail$/.test(url.pathname);
      return url.origin === window.location.origin && !url.username && !url.password && isThumbnailPath ? url.href : null;
    } catch (_) {
      return null;
    }
  }

  function revokeLibraryThumbnails(ids = null) {
    const wanted = ids ? new Set(ids) : null;
    if (!wanted) {
      if (libraryThumbnailObserver) libraryThumbnailObserver.disconnect();
      libraryThumbnailGeneration += 1;
      STATE.library.renderRevision = (STATE.library.renderRevision || 0) + 1;
      document.querySelectorAll("[data-library-thumbnail-id]").forEach(image => image.removeAttribute("src"));
    }
    Array.from(libraryThumbnailControllers.entries()).forEach(([id, entry]) => {
      if (!wanted || wanted.has(id)) entry.controller.abort();
    });
    for (let index = libraryThumbnailQueue.length - 1; index >= 0; index -= 1) {
      if (!wanted || wanted.has(libraryThumbnailQueue[index].id)) {
        const item = libraryThumbnailQueue[index];
        if (libraryThumbnailLoading.get(item.id) === item.generation) libraryThumbnailLoading.delete(item.id);
        libraryThumbnailQueue.splice(index, 1);
      }
    }
    Array.from(libraryThumbnailUrls.entries()).forEach(([id, objectUrl]) => {
      if (!wanted || wanted.has(id)) {
        URL.revokeObjectURL(objectUrl);
        libraryThumbnailUrls.delete(id);
      }
    });
  }

  async function syncLibraryFiles(options = {}) {
    if (STATE.library.syncing || STATE.library.deletePending || STATE.deleting) return;
    const automatic = Boolean(options.automatic);
    const library = STATE.library;
    let runId = (library.syncRunId || 0) + 1;
    const initialAccountKey = library.accountKey;
    library.syncRunId = runId;
    library.syncing = true;
    library.syncProgress = 0;
    render();

    const snapshot = library.isComplete && library.accountKey
      ? {
        accountKey: library.accountKey,
        files: library.files.slice(),
        selectedIds: new Set(library.selectedIds),
        cacheLoadedAt: library.cacheLoadedAt,
        deleteApiAvailable: library.deleteApiAvailable,
        syncApiAvailable: library.syncApiAvailable,
        visibleLimit: library.visibleLimit
      }
      : null;
    if (!globalThis.GPTBDLibrary?.fetchLibraryFiles) {
      library.lastError = "Library module is unavailable. Reload the extension, then refresh ChatGPT.";
      library.syncing = false;
      render();
      if (!automatic) showToast(`${library.lastError} Use Resync Library to retry.`);
      return;
    }
    let syncSucceeded = false;
    let progressiveStarted = false;
    let session = options.sessionHint || null;
    try {
      if (!session) session = await getSessionContext();
      if (!session?.accessToken || !session.accountKey) {
        throw new Error("Could not read your ChatGPT session. Refresh the page and try again.");
      }
      if (library.syncRunId !== runId) {
        if (!initialAccountKey && library.accountKey === session.accountKey) {
          runId = library.syncRunId;
          library.syncing = true;
        } else {
          throw new Error("Your ChatGPT account changed while Library files were syncing.");
        }
      }
      if (library.accountKey !== session.accountKey) {
        revokeLibraryThumbnails();
        GPTBDLibraryUi?.loadCache?.(library, window.localStorage, session.accountKey);
        if (library.syncRunId !== runId) throw new Error("Your ChatGPT account changed while Library files were syncing.");
        library.syncing = true;
      }
      const files = await GPTBDLibrary.fetchLibraryFiles({
        accessToken: session.accessToken,
        fetchImpl: fetch,
        deleteApi: GPTBDDelete,
        delayImpl: delay,
        onCheckpoint: checkpoint => {
          if (library.syncRunId !== runId) return;
          library.syncProgress = Number(checkpoint?.syncedCount) || 0;
          render();
        },
        onPage: async page => {
          const freshSession = await getSessionContext();
          if (!freshSession?.accessToken || freshSession.accountKey !== session.accountKey || library.syncRunId !== runId) {
            throw new Error("Your ChatGPT account changed while Library files were syncing. The result was discarded.");
          }
          session.accessToken = freshSession.accessToken;
          if (!progressiveStarted) {
            progressiveStarted = true;
            revokeLibraryThumbnails();
            library.files = [];
            library.visibleLimit = 50;
          }
          const additions = GPTBDLibraryUi?.normalizeFiles?.(page?.files) || [];
          const known = new Set(library.files.map(file => file.id));
          additions.forEach(file => { if (!known.has(file.id)) library.files.push(file); });
          library.selectedIds.clear();
          library.visibleLimit = Math.max(50, library.visibleLimit);
          library.isComplete = false;
          library.syncProgress = Number(page?.syncedCount) || library.files.length;
          render();
        }
      });
      syncSucceeded = true;
      const freshSession = await getSessionContext();
      if (!freshSession?.accessToken || freshSession.accountKey !== session.accountKey || library.syncRunId !== runId) {
        throw new Error("Your ChatGPT account changed while Library files were syncing. The result was discarded.");
      }
      session.accessToken = freshSession.accessToken;
      revokeLibraryThumbnails();
      library.files = GPTBDLibraryUi?.normalizeFiles?.(files) || files;
      library.selectedIds.clear();
      library.visibleLimit = 50;
      library.cacheLoadedAt = Date.now();
      library.accountKey = session.accountKey;
      library.syncApiAvailable = true;
      library.deleteApiAvailable = null;
      library.isComplete = true;
      library.lastError = "";
      GPTBDLibraryUi?.persistCache?.(library, window.localStorage);
      showToast(`Loaded ${library.files.length.toLocaleString()} Library files for this browser session.`);
    } catch (error) {
      if (library.syncRunId !== runId) return;
      if (snapshot && snapshot.accountKey === library.accountKey) {
        revokeLibraryThumbnails();
        library.files = snapshot.files;
        library.selectedIds = snapshot.selectedIds;
        library.cacheLoadedAt = snapshot.cacheLoadedAt;
        library.deleteApiAvailable = snapshot.deleteApiAvailable;
        library.syncApiAvailable = snapshot.syncApiAvailable;
        library.visibleLimit = snapshot.visibleLimit;
        library.isComplete = true;
      } else {
        revokeLibraryThumbnails();
        library.files = [];
        library.selectedIds.clear();
        library.cacheLoadedAt = null;
        library.isComplete = false;
        if (!syncSucceeded) library.syncApiAvailable = false;
      }
      library.lastError = error instanceof Error && error.message ? error.message : "Library sync failed.";
      if (!automatic) showToast(`${library.lastError} Use Resync Library to retry.`);
    } finally {
      if (library.syncRunId === runId) {
        library.syncing = false;
        library.syncProgress = 0;
        render();
      }
    }
  }

  async function deleteSelectedLibraryFiles() {
    const library = STATE.library;
    const ids = Array.from(library.selectedIds);
    if (!ids.length || STATE.deleting || library.deletePending || library.syncing || !library.isComplete || library.deleteApiAvailable === false) return;
    library.deletePending = true;
    render();
    const session = await getSessionContext();
    if (!session?.accessToken || !session.accountKey || library.accountKey !== session.accountKey || library.syncing || !library.isComplete) {
      showToast("Your ChatGPT account changed. Sync Library again before deleting files.");
      library.deletePending = false;
      render();
      return;
    }
    await restoreDeleteCooldown(session.accountKey);
    if (isDeleteCoolingDown(session.accountKey)) {
      showToast(formatDeleteCooldownMessage());
      scheduleDeleteCooldownEnd();
      render();
      library.deletePending = false;
      render();
      return;
    }
    const files = ids.map(id => library.files.find(file => file.id === id)).filter(Boolean);
    if (files.length !== ids.length) {
      showToast("Some selected Library files are no longer in this session list. Sync Library and try again.");
      library.deletePending = false;
      render();
      return;
    }
    const confirmed = await showDeleteModal(ids, files.map(file => file.title || file.fileName || "Unnamed file"), { mode: "library" });
    if (!confirmed) {
      library.deletePending = false;
      render();
      return;
    }

    const refreshedSession = await getSessionContext();
    const selectedFiles = ids.map(id => library.files.find(file => file.id === id)).filter(Boolean);
    if (!refreshedSession?.accessToken || refreshedSession.accountKey !== session.accountKey || library.syncing || !library.isComplete || selectedFiles.length !== ids.length || !ids.every(id => library.selectedIds.has(id))) {
      showToast("Your ChatGPT account changed before deletion started. Sync Library again before deleting files.");
      library.deletePending = false;
      render();
      return;
    }
    session.accessToken = refreshedSession.accessToken;

    STATE.deleting = true;
    STATE.deleteProgress = { current: 0, total: selectedFiles.length };
    render();
    let result;
    try {
      result = await GPTBDDelete.runDeleteBatch({
        ids: selectedFiles,
        deleteOne: async file => {
          try {
            const liveSession = await getSessionContext();
            if (!liveSession?.accessToken || liveSession.accountKey !== session.accountKey) {
              throw new GPTBDDelete.DeleteBatchPauseError("auth", "Your ChatGPT account changed during Library deletion.");
            }
            session.accessToken = liveSession.accessToken;
            const deleted = await GPTBDLibrary.deleteLibraryFile({
              file,
              accessToken: session.accessToken,
              deleteApi: GPTBDDelete
            });
            if (deleted) {
              library.deleteApiAvailable = true;
              return true;
            }
            library.deleteApiAvailable = false;
            throw new GPTBDDelete.DeleteBatchPauseError("incompatible", "Library delete could not be verified.");
          } catch (error) {
            if (error instanceof GPTBDDelete.DeleteBatchPauseError) {
              if (error.reason === "api" || error.reason === "incompatible") library.deleteApiAvailable = false;
              throw error;
            }
            library.deleteApiAvailable = false;
            throw new GPTBDDelete.DeleteBatchPauseError("incompatible", "Library delete API is unavailable.");
          }
        },
        delayImpl: delay,
        minIntervalMs: 1200,
        onDeleted(file) {
          if (STATE.library.accountKey !== session.accountKey) return;
          library.selectedIds.delete(file.id);
          library.files = library.files.filter(existing => existing.id !== file.id);
          revokeLibraryThumbnails([file.id]);
          GPTBDLibraryUi?.persistCache?.(library, window.localStorage);
        },
        onProgress(progress) {
          STATE.deleteProgress.current = progress.processed;
          render();
        }
      });
      if (result.rateLimitError) {
        await persistDeleteCooldown(session.accountKey, Date.now() + (result.rateLimitError.retryAfterMs || DEFAULT_DELETE_COOLDOWN_MS));
        scheduleDeleteCooldownEnd();
      }
    } catch (_) {
      showToast("Library delete paused unexpectedly. Remaining files were left in the cache.");
      return;
    } finally {
      STATE.deleting = false;
      library.deletePending = false;
      render();
    }
    const deleted = result.deleted;
    const failed = result.failedIds.length;
    const noun = deleted === 1 ? "file" : "files";
    if (result.pauseError) {
      library.lastError = result.pauseError.message || "Library deletion paused.";
      const rateLimit = result.rateLimitError
        ? ` ${formatRateLimitWait(result.rateLimitError.retryAfterMs)}`
        : "";
      showToast(`Removed ${deleted} Library ${noun}. ${failed} selected file${failed === 1 ? " is" : "s are"} unconfirmed or unprocessed; resync to check.${rateLimit}`);
    } else if (failed) {
      library.lastError = "Library deletion could not be confirmed.";
      showToast(`Removed ${deleted} Library ${noun}. ${failed} file${failed === 1 ? " failed" : "s failed"}; the delete API was disabled for safety.`);
    } else {
      library.lastError = "";
      showToast(`Removed ${deleted} Library ${noun}.`);
    }
  }

  /* ─────────────────────── CONVERSATION ROW HELPERS ─────────────────────── */
  function getConversationRows() {
    const pageContext = getPageContext();
    const activeScope = getEffectiveResultScope(pageContext);
    const projectRows = activeScope === "project"
      ? buildConversationRowItems(getProjectConversationLinks(), "project")
      : [];
    const sidebarRows = buildConversationRowItems(getSidebarConversationLinks(), "sidebar");

    return uniqueConversationRows(activeScope === "project" ? projectRows : sidebarRows);
  }

  function getFirstConversationRow() {
    return getConversationRows()[0] || null;
  }

  function hasVisibleSidebarConversationRow() {
    return getSidebarConversationLinks().some(link => {
      const row = findConversationRow(link, "sidebar");
      return isElementVisible(row);
    });
  }

  function getSidebarConversationLinks() {
    const sidebarRoots = Array.from(document.querySelectorAll(SELECTORS.sidebarRoots));
    const scopedLinks = sidebarRoots.flatMap(r => Array.from(r.querySelectorAll(SELECTORS.conversationLinks)));
    return scopedLinks.length > 0 ? scopedLinks : Array.from(document.querySelectorAll(SELECTORS.conversationLinks));
  }

  function getProjectConversationLinks() {
    return Array.from(document.querySelectorAll(SELECTORS.conversationLinks))
      .filter(link => isProjectConversationLink(link));
  }

  function buildConversationRowItems(links, source) {
    return links
      .map(link => {
        if (!(link instanceof HTMLElement)) return null;
        const href = getConversationHref(link);
        const match = href.match(/\/c\/([a-zA-Z0-9-]+)/);
        if (!match) return null;
        const row = findConversationRow(link, source);
        if (!row || row.dataset.gptbdIgnore === "true" || row.dataset.gptbdDeleted === "true") return null;
        return { id: match[1], link, row, source };
      })
      .filter(Boolean);
  }

  function getConversationHref(element) {
    return element.getAttribute("href")
      || element.getAttribute("data-href")
      || element.dataset?.href
      || "";
  }

  function uniqueConversationRows(rows) {
    return rows.filter((item, index, arr) => arr.findIndex(other => other.id === item.id) === index);
  }

  function findConversationRow(link, source = "sidebar") {
    const preferred = link.closest("li, [role='listitem']");
    if (preferred) return preferred;

    let node = link;
    let depth = 0;
    while (node && node !== document.body) {
      if (source === "project" && (node.matches("main") || depth > 5)) break;
      if (node.querySelectorAll("button").length > 0) return node;
      node = node.parentElement;
      depth += 1;
    }
    return link.parentElement;
  }

  function isProjectConversationLink(link) {
    if (!(link instanceof HTMLElement)) return false;
    if (link.closest("#gpt-bulk-delete-root")) return false;
    if (link.closest(SELECTORS.sidebarRoots)) return false;
    if (link.closest(SELECTORS.messageRoots)) return false;
    if (!link.closest("main")) return false;

    const row = findConversationRow(link, "project");
    if (!row || row === document.body || row.matches("main")) return false;
    if (!isElementVisible(link) && !isElementVisible(row)) return false;
    if (row.querySelectorAll(SELECTORS.conversationLinks).length > 3) return false;

    const title = getConversationTitle(link, row);
    return title.length > 0;
  }

  function getPageContext() {
    const path = window.location.pathname.toLowerCase();
    const main = document.querySelector("main");
    const isProjectUrl =
      /^\/projects?(\/|$)/.test(path) ||
      /\/projects?(\/|$)/.test(path) ||
      /\/g\/g-p-[^/]+/.test(path);
    const hasProjectDomSignal = Array.from(main?.querySelectorAll(SELECTORS.projectSignals) || [])
      .some(el => !el.closest(SELECTORS.messageRoots));
    const projectName = getProjectName();
    const projectKey = getProjectKey(path, projectName);

    return {
      mode: isProjectUrl || hasProjectDomSignal ? "project" : "default",
      projectName,
      projectKey
    };
  }

  function getEffectiveResultScope(pageContext = getPageContext()) {
    if (pageContext.mode !== "project") return "account";
    return STATE.resultScope === "account" && STATE.cachedConversations.length > 0 ? "account" : "project";
  }

  function getProjectName() {
    const heading = Array.from(document.querySelectorAll("main h1, main [role='heading']"))
      .map(el => normalizeText(el.textContent))
      .find(Boolean);
    return heading || "";
  }

  function getSelectionContext(ids = Array.from(STATE.selectedIds)) {
    const projectIds = new Set(
      getConversationRows()
        .filter(item => item.source === "project")
        .map(item => item.id)
    );
    const isProjectOnlySelection = ids.length > 0 && ids.every(id => projectIds.has(id));
    return {
      mode: isProjectOnlySelection ? "project" : "default"
    };
  }

  function getProjectKey(path = window.location.pathname.toLowerCase(), projectName = "") {
    const normalizedPath = normalizeText(path).toLowerCase();
    const slugMatch = normalizedPath.match(/\/projects?\/([^/?#]+)/)
      || normalizedPath.match(/\/g\/(g-p-[^/?#]+)/);
    if (slugMatch?.[1]) return `path:${decodeURIComponent(slugMatch[1])}`;
    const name = normalizeText(projectName).toLowerCase();
    if (name) return `name:${name}`;
    return "";
  }

  function rememberProjectMembership(pageContext, rows) {
    if (pageContext.mode !== "project" || !pageContext.projectKey || rows.length === 0) return;
    const ids = rows.filter(item => item.source === "project").map(item => item.id);
    if (ids.length === 0) return;

    const existing = STATE.projectIndex.memberships[pageContext.projectKey] || {};
    const mergedIds = Array.from(new Set([...(existing.ids || []), ...ids]));
    const name = pageContext.projectName || existing.name || "Untitled project";
    const updatedAt = Date.now();
    const sameIds = Array.isArray(existing.ids)
      && existing.ids.length === mergedIds.length
      && existing.ids.every(id => mergedIds.includes(id));
    const sameName = existing.name === name;
    if (sameIds && sameName) return;

    STATE.projectIndex.memberships[pageContext.projectKey] = {
      name,
      ids: mergedIds,
      updatedAt
    };
    STATE.projectIndex.projects = upsertProjectSummary(STATE.projectIndex.projects, {
      key: pageContext.projectKey,
      name,
      updatedAt
    });
    persistProjectIndex();
  }

  function upsertProjectSummary(projects, project) {
    const next = projects.filter(item => item.key !== project.key);
    next.push(project);
    return next
      .filter(item => item?.key && item?.name)
      .sort((a, b) => String(a.name).localeCompare(String(b.name)));
  }

  function getKnownProjects() {
    return STATE.projectIndex.projects
      .filter(project => project?.key && project?.name)
      .sort((a, b) => String(a.name).localeCompare(String(b.name)));
  }

  function getProjectFilterLabel(projectKey) {
    if (!projectKey || projectKey === "all") return "";
    const project = STATE.projectIndex.projects.find(item => item.key === projectKey);
    return project?.name ? `project ${project.name}` : "selected project";
  }

  function rememberSidebarProjects() {
    const projects = getSidebarProjects();
    if (projects.length === 0) return;

    let changed = false;
    projects.forEach(project => {
      const existing = STATE.projectIndex.projects.find(item => item.key === project.key);
      if (!existing) {
        STATE.projectIndex.projects = upsertProjectSummary(STATE.projectIndex.projects, project);
        changed = true;
        return;
      }
      if (existing.name !== project.name) {
        STATE.projectIndex.projects = upsertProjectSummary(STATE.projectIndex.projects, {
          ...existing,
          name: project.name
        });
        const membership = STATE.projectIndex.memberships[project.key];
        if (membership) {
          STATE.projectIndex.memberships[project.key] = { ...membership, name: project.name };
        }
        changed = true;
      }
    });

    if (changed) persistProjectIndex();
  }

  function getSidebarProjects() {
    const sidebarRoots = Array.from(document.querySelectorAll(SELECTORS.sidebarRoots));
    const links = sidebarRoots.flatMap(root => Array.from(root.querySelectorAll(SELECTORS.projectLinks)));
    return links
      .map(link => {
        if (!(link instanceof HTMLElement) || !isElementVisible(link)) return null;
        const href = link.getAttribute("href") || "";
        const name = normalizeText(link.textContent);
        if (!href || !name) return null;
        const path = toPathname(href);
        const key = getProjectKey(path, name);
        if (!key) return null;
        return { key, name, updatedAt: Date.now() };
      })
      .filter(Boolean)
      .filter((project, index, arr) => arr.findIndex(other => other.key === project.key) === index);
  }

  function toPathname(href) {
    try {
      return new URL(href, window.location.origin).pathname;
    } catch (_) {
      return href;
    }
  }

  function refreshConversationRows() {
    rememberSidebarProjects();

    const rows = getConversationRows();
    const liveIds = new Set(rows.map(r => r.id));
    const activeScope = getEffectiveResultScope();
    const pageContext = getPageContext();
    const cachedIds = activeScope === "project" ? new Set() : new Set(STATE.cachedConversations.map(c => c.id));

    if (activeScope === "project") {
      rememberProjectMembership(pageContext, rows);
    }

    for (const id of Array.from(STATE.selectedIds)) {
      if (!liveIds.has(id) && !cachedIds.has(id)) STATE.selectedIds.delete(id);
    }

    rows.forEach(({ id, row, link, source }) => {
      const title = getConversationTitle(link, row);
      row.dataset.gptbdConversationId = id;
      row.dataset.gptbdConversationTitle = title;
      row.dataset.gptbdConversationSource = source;
      row.classList.toggle("gptbd-row-enabled", STATE.enabled);
      row.classList.toggle("gptbd-row-selected", STATE.selectedIds.has(id));
      applySearchState(row, title);

      /* Inject checkbox */
      let checkbox = row.querySelector(".gptbd-checkbox");
      if (!checkbox) {
        checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.className = "gptbd-checkbox";
        checkbox.setAttribute("aria-label", "Select conversation for deletion");

        checkbox.addEventListener("click", event => event.stopPropagation());

        checkbox.addEventListener("change", event => {
          const currentRow = event.target.closest("[data-gptbd-conversation-id]");
          const currentId = currentRow?.dataset.gptbdConversationId;
          if (!currentId) return;

          const checked = event.target.checked;

          /* Shift-range select */
          if (event.shiftKey && STATE.lastSelectedId && STATE.lastSelectedId !== currentId) {
            const allRows = getRangeSelectableRows();
            const allIds = allRows.map(r => r.id);
            const cIdx = allIds.indexOf(currentId);
            const lIdx = allIds.indexOf(STATE.lastSelectedId);
            if (cIdx !== -1 && lIdx !== -1) {
              const lo = Math.min(cIdx, lIdx);
              const hi = Math.max(cIdx, lIdx);
              for (let i = lo; i <= hi; i++) {
                if (checked) STATE.selectedIds.add(allIds[i]);
                else STATE.selectedIds.delete(allIds[i]);
              }
              syncCheckboxes();
              STATE.lastSelectedId = currentId;
              render();
              return;
            }
          }

          if (checked) STATE.selectedIds.add(currentId);
          else STATE.selectedIds.delete(currentId);
          currentRow.classList.toggle("gptbd-row-selected", checked);
          STATE.lastSelectedId = currentId;
          render();
        });
      }

      checkbox.checked = STATE.selectedIds.has(id);
      checkbox.hidden = !STATE.enabled;
      if (!checkbox.parentElement) row.insertBefore(checkbox, row.firstChild);

      /* Row-click handler (toggling via click anywhere on the row) */
      if (!row.dataset.gptbdBound) {
        row.dataset.gptbdBound = "true";
        row.addEventListener("click", event => {
          if (!STATE.enabled) return;
          if (event.target.closest(".gptbd-checkbox")) return;
          if (event.target.closest("button")) return;

          event.preventDefault();
          event.stopPropagation();

          const currentCheckbox = row.querySelector(".gptbd-checkbox");
          if (!currentCheckbox) return;

          const currentId = row.dataset.gptbdConversationId;
          const newChecked = !currentCheckbox.checked;

          /* Shift-range select from row click */
          if (event.shiftKey && STATE.lastSelectedId && STATE.lastSelectedId !== currentId) {
            const allRows = getRangeSelectableRows();
            const allIds = allRows.map(r => r.id);
            const cIdx = allIds.indexOf(currentId);
            const lIdx = allIds.indexOf(STATE.lastSelectedId);
            if (cIdx !== -1 && lIdx !== -1) {
              const lo = Math.min(cIdx, lIdx);
              const hi = Math.max(cIdx, lIdx);
              for (let i = lo; i <= hi; i++) {
                if (newChecked) STATE.selectedIds.add(allIds[i]);
                else STATE.selectedIds.delete(allIds[i]);
              }
              syncCheckboxes();
              STATE.lastSelectedId = currentId;
              render();
              return;
            }
          }

          currentCheckbox.checked = newChecked;
          currentCheckbox.dispatchEvent(new Event("change", { bubbles: true }));
        }, true);
      }

      link.dataset.gptbdConversationLink = id;
    });
  }

  function syncCheckboxes() {
    Array.from(document.querySelectorAll(".gptbd-checkbox")).forEach(checkbox => {
      const row = checkbox.closest("[data-gptbd-conversation-id]");
      if (!row) return;
      const id = row.dataset.gptbdConversationId;
      const checked = STATE.selectedIds.has(id);
      checkbox.checked = checked;
      row.classList.toggle("gptbd-row-selected", checked);
      checkbox.hidden = !STATE.enabled;
    });
  }

  function selectVisibleRows() {
    getVisibleRows().forEach(({ id }) => STATE.selectedIds.add(id));
    syncCheckboxes();
  }

  function selectAllRows() {
    getSelectableConversationIds().forEach(id => STATE.selectedIds.add(id));
    syncCheckboxes();
  }

  function selectMatchingRows() {
    getSearchResults().forEach(({ id }) => STATE.selectedIds.add(id));
    syncCheckboxes();
  }

  function getSelectableConversationIds() {
    if (getEffectiveResultScope() === "project") return (STATE.searchTerm ? getMatchingRows() : getVisibleRows()).map(item => item.id);
    if (STATE.cachedConversations.length > 0) return getSearchResults().map(item => item.id);
    return (STATE.searchTerm ? getMatchingRows() : getVisibleRows()).map(item => item.id);
  }

  function getVisibleRows() {
    return getConversationRows().filter(({ row }) => !row.classList.contains("gptbd-row-hidden"));
  }

  function needsJumpToChatsHint() {
    const firstRow = getFirstConversationRow();
    if (!firstRow?.row) return false;

    const scrollContainer = getConversationScrollContainer(firstRow.row);
    if (!scrollContainer) return false;

    const rowRect = firstRow.row.getBoundingClientRect();
    const containerRect = scrollContainer.getBoundingClientRect();
    const isAbove = rowRect.top < containerRect.top;
    const isBelow = rowRect.bottom > containerRect.bottom;
    return isAbove || isBelow;
  }

  function jumpToFirstConversationRow() {
    const firstRow = getFirstConversationRow();
    if (!firstRow?.row) return;

    firstRow.row.scrollIntoView({ block: "center", inline: "nearest", behavior: "smooth" });

    const link = firstRow.row.querySelector("a");
    if (link instanceof HTMLElement) {
      window.setTimeout(() => {
        link.focus({ preventScroll: true });
      }, 250);
    }
  }

  function getConversationScrollContainer(row) {
    const sidebarRoot = row.closest("nav, aside, [data-testid='history']");
    if (!(sidebarRoot instanceof HTMLElement)) return null;

    let node = row.parentElement;
    while (node && node !== sidebarRoot) {
      if (isScrollable(node)) return node;
      node = node.parentElement;
    }

    return isScrollable(sidebarRoot) ? sidebarRoot : sidebarRoot;
  }

  function getRangeSelectableRows() {
    return STATE.searchTerm ? getMatchingRows() : getConversationRows();
  }

  function getMatchingRows() {
    if (!STATE.searchTerm) return getConversationRows();
    return getConversationRows().filter(({ row, link }) => {
      const title = row.dataset.gptbdConversationTitle || getConversationTitle(link, row);
      return matchesSearch(title, STATE.searchTerm);
    });
  }

  function getSearchResults() {
    if (getEffectiveResultScope() === "project") {
      return getMatchingRows().map(({ id, link, row }) => ({
        id,
        title: getConversationTitle(link, row) || "Untitled chat"
      }));
    }
    if (STATE.cachedConversations.length > 0) {
      return sortCachedResults(filterCachedResults(STATE.cachedConversations));
    }
    return getMatchingRows().map(({ id, link, row }) => ({
      id,
      title: getConversationTitle(link, row) || "Untitled chat"
    }));
  }

  function getConversationTitle(link, row) {
    const linkText = normalizeText(link?.textContent);
    if (linkText) return linkText;
    const rowText = normalizeText(row?.textContent);
    if (!rowText) return "";
    return rowText;
  }

  function applySearchState(row, title) {
    const hasSearch = Boolean(STATE.searchTerm);
    const isMatch = !hasSearch || matchesSearch(title, STATE.searchTerm);
    row.classList.toggle("gptbd-row-match", hasSearch && isMatch);
    row.classList.remove("gptbd-row-hidden");
  }

  /* ─────────────────────────── DELETE FLOW ──────────────────────────────── */
  async function deleteSelectedConversations() {
    const ids = Array.from(STATE.selectedIds);
    if (ids.length === 0 || STATE.deleting || STATE.library.deletePending) return;

    await ensureCapabilityHealth({ force: isCapabilityHealthStale(), silent: true });
    if (!STATE.health.deleteApiAvailable && !STATE.health.deleteUiAvailable) {
      showToast(STATE.health.note || "Delete is temporarily unavailable. Refresh ChatGPT and try again.");
      return;
    }
    if (!canDeleteSelection(ids)) {
      showToast("Delete is limited to chats currently visible in the sidebar until ChatGPT compatibility checks pass again.");
      return;
    }
    const currentSession = await getSessionContext();
    const batchSession = STATE.health.deleteApiAvailable ? currentSession : null;
    const cooldownScope = GPTBDDelete.resolveCooldownScope(currentSession, STATE.accountKey);
    if (cooldownScope) await restoreDeleteCooldown(cooldownScope);
    if (isDeleteCoolingDown(cooldownScope)) {
      showToast(formatDeleteCooldownMessage());
      scheduleDeleteCooldownEnd();
      render();
      return;
    }

    /* Resolve display titles for the preview list */
    const titles = ids.map(id => {
      const cached = STATE.cachedConversations.find(c => c.id === id);
      if (cached) return cached.title;
      const row = document.querySelector(`[data-gptbd-conversation-id="${CSS.escape(id)}"]`);
      return row?.dataset.gptbdConversationTitle || "Untitled chat";
    });

    const selectionContext = getSelectionContext(ids);
    const confirmed = await showDeleteModal(ids, titles, selectionContext);
    if (!confirmed) return;

    STATE.deleting = true;
    STATE.deleteProgress = { current: 0, total: ids.length };
    render();

    let result = null;
    let sidebarRefreshed = false;
    try {
      result = await GPTBDDelete.runDeleteBatch({
        ids,
        deleteOne: id => deleteConversationById(id, batchSession),
        delayImpl: delay,
        minIntervalMs: 1200,
        onDeleted(id) {
          STATE.selectedIds.delete(id);
          removeConversationRow(id);
          removeConversationFromCache(id);
        },
        onProgress(progress) {
          STATE.deleteProgress.current = progress.processed;
          refreshConversationRows();
          render();
        }
      });

      if (result.rateLimitError && batchSession?.accountKey) {
        const cooldownMs = result.rateLimitError.retryAfterMs || DEFAULT_DELETE_COOLDOWN_MS;
        await persistDeleteCooldown(batchSession.accountKey, Date.now() + cooldownMs);
        scheduleDeleteCooldownEnd();
      }

      if (result.deleted > 0 && !result.pauseError) {
        sidebarRefreshed = await refreshSidebarAfterDelete();
        refreshConversationRows();
      }
    } catch (_) {
      showToast("Delete paused unexpectedly. No unconfirmed chats were removed from the cache.");
      return;
    } finally {
      STATE.deleting = false;
      render();
    }

    const summary = result.pauseError && !result.rateLimitError
      ? buildPausedDeleteSummary(result.deleted, result.failedIds.length, result.pauseError)
      : buildDeleteSummary(
        result.deleted,
        result.failedIds.length,
        sidebarRefreshed,
        result.rateLimitError
      );
    showToast(summary);
  }

  /* Show the in-DOM confirmation modal; returns Promise<boolean> */
  function showDeleteModal(ids, titles, selectionContext = { mode: "default" }) {
    const isLibraryDelete = selectionContext.mode === "library";
    if (STATE.skipDeleteWarning && !isLibraryDelete) return Promise.resolve(true);

    return new Promise(resolve => {
      const modal = document.getElementById("gptbd-modal");
      if (!modal) { resolve(false); return; }

      const count = ids.length;
      const titleEl = modal.querySelector('[data-role="modal-title"]');
      const previewEl = modal.querySelector('[data-role="modal-preview"]');
      const confirmLabel = modal.querySelector('[data-role="modal-confirm-label"]');
      const warningCheck = modal.querySelector('[data-role="modal-warning-check"]');
      const warningCheckLabel = warningCheck?.closest(".gptbd-modal__check")?.querySelector(".gptbd-modal__check-label");
      const skipWarningCheck = modal.querySelector('[data-role="modal-skip-warning-check"]');
      const confirmBtn = modal.querySelector('[data-action="modal-confirm"]');

      resetModalToDeleteDefaults(modal);
      const skipWarningCheckWrap = skipWarningCheck?.closest(".gptbd-modal__check");
      if (skipWarningCheckWrap) skipWarningCheckWrap.hidden = isLibraryDelete;

      const isProjectDelete = selectionContext.mode === "project";
      const noun = isLibraryDelete ? "Library file" : isProjectDelete ? "project conversation" : "conversation";
      if (titleEl) {
        titleEl.textContent = isLibraryDelete
          ? `Remove ${count}\u00a0${noun}${count === 1 ? "" : "s"}?`
          : `Delete ${count}\u00a0${noun}${count === 1 ? "" : "s"}?`;
      }
      if (isProjectDelete || isLibraryDelete) {
        const subtitleEl = modal.querySelector(".gptbd-modal__subtitle");
        const warningText = modal.querySelector(".gptbd-modal__warning-text");
        if (subtitleEl) {
          subtitleEl.textContent = isLibraryDelete
            ? "Remove selected files from your ChatGPT Library. Conversations are not deleted."
            : "Permanent. This deletes the chat, not just removes it from the project.";
        }
        if (warningText) {
          warningText.textContent = isLibraryDelete
            ? "These Library files will be removed from your ChatGPT Library. Conversations are not deleted."
            : "These project chats will be permanently deleted from ChatGPT, not just removed from this project.";
        }
      }
      if (warningCheckLabel && isLibraryDelete) {
        warningCheckLabel.textContent = "I understand these selected files will be removed from my ChatGPT Library.";
      }
      if (confirmLabel) {
        const confirmNoun = isLibraryDelete ? "Library file" : isProjectDelete ? "project chat" : "conversation";
        confirmLabel.textContent = `${isLibraryDelete ? "Remove" : "Delete"}\u00a0${count}\u00a0${confirmNoun}${count === 1 ? "" : "s"}`;
      }
      if (warningCheck) warningCheck.checked = false;
      if (skipWarningCheck) skipWarningCheck.checked = false;
      if (confirmBtn) confirmBtn.disabled = true;

      if (previewEl) {
        const maxShow = 8;
        const shown = titles.slice(0, maxShow);
        const remaining = titles.length - shown.length;
        replaceChildren(previewEl, buildDeletePreviewItems(shown, remaining));
      }

      modal.dataset.visible = "true";

      function syncConfirmState() {
        if (confirmBtn && warningCheck) {
          confirmBtn.disabled = !warningCheck.checked;
        }
      }

      syncConfirmState();
      if (warningCheck) warningCheck.addEventListener("change", syncConfirmState);

      /* Focus warning checkbox first so the required action is obvious */
      window.setTimeout(() => { if (warningCheck) warningCheck.focus(); }, 60);

      async function done(result) {
        if (result && !isLibraryDelete && skipWarningCheck?.checked) {
          await setSkipDeleteWarningPreference(true);
        }
        if (warningCheck) warningCheck.removeEventListener("change", syncConfirmState);
        modal.dataset.visible = "false";
        document.removeEventListener("keydown", onKeydown);
        activeModalResolve = null;
        resolve(result);
      }

      function onKeydown(e) {
        if (e.key === "Escape") done(false);
      }

      document.addEventListener("keydown", onKeydown);
      activeModalResolve = done;
    });
  }

  function showClearCacheModal() {
    return new Promise(resolve => {
      const modal = document.getElementById("gptbd-modal");
      if (!modal) { resolve(false); return; }

      resetModalToDeleteDefaults(modal);

      const titleEl = modal.querySelector('[data-role="modal-title"]');
      const subtitleEl = modal.querySelector(".gptbd-modal__subtitle");
      const previewEl = modal.querySelector('[data-role="modal-preview"]');
      const warningWrap = modal.querySelector(".gptbd-modal__warning");
      const warningText = modal.querySelector(".gptbd-modal__warning-text");
      const warningCheckWrap = modal.querySelector('[data-role="modal-warning-check"]')?.closest(".gptbd-modal__check");
      const skipWarningCheckWrap = modal.querySelector('[data-role="modal-skip-warning-check"]')?.closest(".gptbd-modal__check");
      const confirmLabel = modal.querySelector('[data-role="modal-confirm-label"]');
      const confirmBtn = modal.querySelector('[data-action="modal-confirm"]');

      if (titleEl) titleEl.textContent = "Clear local cache?";
      if (subtitleEl) subtitleEl.textContent = "This removes the synced chat list stored in the extension on this browser only.";
      if (previewEl) {
        replaceChildren(previewEl, buildClearCachePreviewItems());
      }
      if (warningWrap) warningWrap.hidden = false;
      if (warningText) warningText.textContent = "Clearing local cache removes the saved chat list from this browser.";
      if (warningCheckWrap) warningCheckWrap.hidden = true;
      if (skipWarningCheckWrap) skipWarningCheckWrap.hidden = true;
      if (confirmLabel) confirmLabel.textContent = "Clear cache";
      if (confirmBtn) confirmBtn.disabled = false;

      modal.dataset.visible = "true";
      window.setTimeout(() => { if (confirmBtn) confirmBtn.focus(); }, 60);

      function resetModal() {
        resetModalToDeleteDefaults(modal);
      }

      function done(result) {
        resetModal();
        modal.dataset.visible = "false";
        document.removeEventListener("keydown", onKeydown);
        activeModalResolve = null;
        resolve(result);
      }

      function onKeydown(e) {
        if (e.key === "Escape") done(false);
      }

      document.addEventListener("keydown", onKeydown);
      activeModalResolve = done;
    });
  }

  /* ───────────────────────── INDIVIDUAL DELETION ─────────────────────────── */
  async function deleteConversationById(id, session) {
    const apiDeleted = await deleteConversationByApi(id, session);
    if (apiDeleted) return true;

    const row = document.querySelector(`[data-gptbd-conversation-id="${CSS.escape(id)}"]`);
    if (!row) {
      registerCapabilityFailure("deleteUi", "Chat row was not available for UI fallback.");
      return false;
    }

    row.scrollIntoView({ block: "center" });
    revealRowActions(row);
    await delay(220);

    const menuButton = findMenuButton(row);
    if (!menuButton) {
      registerCapabilityFailure("deleteUi", "Could not find the conversation menu button.");
      return false;
    }

    const menuSurfacesBefore = getVisibleMenuSurfaces();
    openConversationMenu(menuButton);
    const menuSurface = await waitForMenuSurface(menuSurfacesBefore);
    const deleteControl = await waitForDeleteMenuItem(menuSurface);
    if (!deleteControl) {
      dismissOpenMenus();
      registerCapabilityFailure("deleteUi", "Could not find the delete action in the conversation menu.");
      return false;
    }

    const dialogsBefore = getVisibleDialogs();
    deleteControl.click();

    const confirmButton = await waitForDeleteConfirmButton(dialogsBefore);
    if (!confirmButton) {
      dismissOpenMenus();
      registerCapabilityFailure("deleteUi", "Could not find the delete confirmation dialog.");
      return false;
    }

    confirmButton.click();
    const removed = await waitForConversationRemoval(id, 5000);
    if (removed) {
      registerCapabilitySuccess("deleteUi");
      return true;
    }
    registerCapabilityFailure("deleteUi", "UI delete did not remove the conversation.");
    return false;
  }

  async function deleteConversationByApi(id, session, authRetried = false) {
    try {
      const accessToken = session?.accessToken || null;
      if (!accessToken) {
        registerCapabilityFailure("deleteApi", "Could not read the ChatGPT session token.");
        return false;
      }

      const response = await GPTBDDelete.fetchWithTimeout(fetch, `/backend-api/conversation/${encodeURIComponent(id)}`, {
        method: "PATCH",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`
        },
        body: JSON.stringify({ is_visible: false })
      }, 30 * 1000);

      if (!response.ok) {
        if (response.status === 429) {
          throw new GPTBDDelete.DeleteRateLimitError(GPTBDDelete.parseRetryAfterMs(response));
        }
        if (response.status === 401 || response.status === 403) {
          if (!authRetried) {
            const refreshed = await getSessionContext();
            if (refreshed?.accessToken && refreshed.accountKey === session?.accountKey) {
              session.accessToken = refreshed.accessToken;
              return deleteConversationByApi(id, session, true);
            }
          }
          throw new GPTBDDelete.DeleteBatchPauseError(
            "auth",
            "Your ChatGPT session changed during the delete batch."
          );
        }
        registerCapabilityFailure("deleteApi", `Delete API returned ${response.status}.`);
        return false;
      }
      // An API mutation does not update ChatGPT's client-side sidebar state.
      // Confirm with the response, then let onDeleted update our list/cache.
      if (response.status !== 204) {
        let timeoutId;
        let payload;
        try {
          payload = await Promise.race([
            response.json(),
            new Promise((_, reject) => {
              timeoutId = window.setTimeout(() => reject(new Error("Delete confirmation timed out")), 10000);
            })
          ]);
        } catch (_) {
          throw new GPTBDDelete.DeleteBatchPauseError("incompatible", "ChatGPT did not return a readable deletion confirmation. Resync to check the remaining chats.");
        } finally {
          window.clearTimeout(timeoutId);
        }
        if (payload?.success !== true) {
          throw new GPTBDDelete.DeleteBatchPauseError("incompatible", "ChatGPT did not confirm deletion. Resync to check the remaining chats.");
        }
      }
      registerCapabilitySuccess("deleteApi");
      return true;
    } catch (error) {
      if (error instanceof GPTBDDelete.DeleteBatchPauseError) throw error;
      registerCapabilityFailure("deleteApi", "Delete API request failed.");
      return false;
    }
  }

  function findMenuButton(row) {
    const buttons = Array.from(row.querySelectorAll(SELECTORS.menuButtons));
    return buttons
      .filter(b => b instanceof HTMLElement)
      .map(b => ({ button: b, score: scoreMenuButton(b) }))
      .sort((a, b) => b.score - a.score)[0]?.button || null;
  }

  async function waitForDeleteMenuItem(menuSurface) {
    return waitFor(() => {
      if (!(menuSurface instanceof HTMLElement) || !isElementVisible(menuSurface)) return null;
      const items = Array.from(menuSurface.querySelectorAll(SELECTORS.menuItems)).filter(item => {
        return isElementVisible(item) && !item.closest("#gpt-bulk-delete-root");
      });
      const exact = items.find(item => /delete|trash/i.test(normalizeText(item.textContent)));
      if (exact) return exact;

      const danger = items.find(item => {
        const text = normalizeText(item.textContent);
        const cls = typeof item.className === "string" ? item.className : "";
        return /delete|remove/i.test(text) || /danger|error|destructive/i.test(cls);
      });
      if (danger) return danger;

      const menuItems = items.filter(item => item.getAttribute("role") === "menuitem");
      return menuItems.at(-1) || null;
    }, 2500);
  }

  async function waitForDeleteConfirmButton(dialogsBefore = []) {
    return waitFor(() => {
      const beforeSet = new Set(dialogsBefore);
      const dialogs = getVisibleDialogs();
      const preferredDialogs = dialogs.filter(dialog => !beforeSet.has(dialog));
      for (const dialog of preferredDialogs.length > 0 ? preferredDialogs : dialogs) {
        const match = Array.from(dialog.querySelectorAll("button"))
          .find(b => /^delete$/i.test(normalizeText(b.textContent)));
        if (match) return match;
      }
      return null;
    }, 4000);
  }

  async function waitForConversationRemoval(id, timeoutMs) {
    const removed = await waitFor(() => {
      return !document.querySelector(`[data-gptbd-conversation-id="${CSS.escape(id)}"]`);
    }, timeoutMs);
    return Boolean(removed);
  }

  async function waitFor(checkFn, timeoutMs) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const result = checkFn();
      if (result) return result;
      await delay(120);
    }
    return null;
  }

  function dismissOpenMenus() {
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
  }

  /* ───────────────────────────── TOAST ─────────────────────────────────── */
  function showToast(message) {
    const toast = document.querySelector(".gptbd-toast");
    if (!toast) return;
    toast.textContent = message;
    toast.dataset.visible = "true";
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => { toast.dataset.visible = "false"; }, 4000);
  }

  /* ──────────────────────────── SYNC ALL ────────────────────────────────── */
  async function syncAllChats() {
    if (STATE.syncingAll || STATE.deleting || STATE.library.deletePending) return;
    await ensureCapabilityHealth({ force: isCapabilityHealthStale(), silent: true });
    if (!STATE.health.syncAvailable) {
      showToast(STATE.health.note || "Sync is temporarily unavailable. Refresh ChatGPT and try again.");
      return;
    }

    STATE.syncingAll = true;
    render();

    try {
      const session = await getSessionContext();
      if (!session?.accessToken) {
        registerCapabilityFailure("sync", "Could not read your ChatGPT session.");
        showToast("Could not read your ChatGPT session. Refresh the page and try again.");
        return;
      }
      const checkpoint = await loadSyncCheckpoint(session.accountKey);
      const conversations = await fetchAllConversations(session, checkpoint);
      registerCapabilitySuccess("sync");
      STATE.cachedConversations = conversations;
      STATE.cacheLoadedAt = Date.now();
      if (!persistCache()) {
        throw new Error("Sync finished, but the local cache is full. Clear the old cache and try again.");
      }
      await clearSyncCheckpoint();
      await ensureCapabilityHealth({ force: true, silent: true });
      render();
      showToast(`Synced ${conversations.length.toLocaleString()} chats to cache.`);
    } catch (error) {
      registerCapabilityFailure("sync", error instanceof Error ? error.message : "Sync failed.");
      await ensureCapabilityHealth({ force: true, silent: true });
      const partialCount = error instanceof GPTBDSync.SyncPausedError && error.checkpointSaved
        ? error.checkpoint?.syncedCount || 0
        : 0;
      const message = partialCount > 0
        ? `Sync paused after ${partialCount.toLocaleString()} chats. Click Sync again to retry safely.`
        : error instanceof GPTBDSync.SyncPausedError && error.checkpoint?.syncedCount > 0
          ? "Sync paused, but progress could not be saved. Click Sync to restart."
        : error instanceof Error && error.message
          ? error.message
          : "Sync failed. Refresh ChatGPT and try again.";
      showToast(message);
    } finally {
      STATE.syncingAll = false;
      render();
    }
  }

  async function fetchAllConversations(session, checkpoint) {
    let checkpointSaved = false;
    let records;
    const options = {
      accessToken: session.accessToken,
      scopeKey: session.accountKey,
      checkpoint,
      fetchImpl: fetch,
      delayImpl: delay,
      onCheckpoint: async value => {
        if (!session.accountKey) return;
        try {
          await persistSyncCheckpoint(value);
          checkpointSaved = true;
        } catch (_) {
          checkpointSaved = false;
        }
      },
      mapItem: mapConversationForSync
    };
    try {
      records = await GPTBDSync.fetchAllConversations(options);
    } catch (error) {
      if (error instanceof GPTBDSync.SyncPausedError && error.checkpoint) {
        try {
          if (!session.accountKey) throw new Error("Missing account identity");
          await persistSyncCheckpoint(error.checkpoint);
          checkpointSaved = true;
        } catch (_) {
          checkpointSaved = false;
        }
        error.checkpointSaved = checkpointSaved;
      }
      throw error;
    }

    const projectMemberships = new Map();
    records.forEach(item => {
      const projectMeta = item.projectMeta;
      if (!projectMeta) return;
      const project = projectMemberships.get(projectMeta.key) || {
        key: projectMeta.key,
        name: projectMeta.name,
        ids: []
      };
      project.ids.push(item.id);
      projectMemberships.set(projectMeta.key, project);
    });

    rememberSyncedProjectMemberships(projectMemberships);

    return records.map(({ projectMeta: _projectMeta, ...conversation }) => conversation).sort((a, b) => {
      const at = a.updateTime ? Date.parse(a.updateTime) : 0;
      const bt = b.updateTime ? Date.parse(b.updateTime) : 0;
      return bt - at;
    });
  }

  function mapConversationForSync(item) {
    if (!item?.id) return null;
    return {
      id: item.id,
      title: normalizeText(item.title) || "Untitled chat",
      updateTime: item.update_time || item.create_time || null,
      projectMeta: extractConversationProjectMeta(item)
    };
  }

  function extractConversationProjectMeta(item) {
    const projectObject = [item?.project, item?.project_info, item?.current_project]
      .find(value => value && typeof value === "object");
    const id = firstString(
      item?.project_id,
      item?.project_uuid,
      item?.current_project_id,
      projectObject?.id,
      projectObject?.project_id,
      projectObject?.uuid
    );
    const name = firstString(
      item?.project_name,
      item?.project_title,
      projectObject?.name,
      projectObject?.title
    );
    if (!id && !name) return null;
    const key = id ? `api:${id}` : `name:${normalizeText(name).toLowerCase()}`;
    return {
      key,
      name: normalizeText(name) || `Project ${String(id).slice(0, 8)}`
    };
  }

  function firstString(...values) {
    const value = values.find(item => typeof item === "string" && normalizeText(item));
    return value ? normalizeText(value) : "";
  }

  function rememberSyncedProjectMemberships(projectMemberships) {
    if (!(projectMemberships instanceof Map) || projectMemberships.size === 0) return;
    let changed = false;
    projectMemberships.forEach(project => {
      const existing = STATE.projectIndex.memberships[project.key] || {};
      const mergedIds = Array.from(new Set([...(existing.ids || []), ...project.ids]));
      const sameIds = Array.isArray(existing.ids)
        && existing.ids.length === mergedIds.length
        && existing.ids.every(id => mergedIds.includes(id));
      const sameName = existing.name === project.name;
      if (!sameIds || !sameName) {
        STATE.projectIndex.memberships[project.key] = {
          name: project.name,
          ids: mergedIds,
          updatedAt: Date.now()
        };
        changed = true;
      }
      const existingSummary = STATE.projectIndex.projects.find(item => item.key === project.key);
      if (!existingSummary || existingSummary.name !== project.name) {
        STATE.projectIndex.projects = upsertProjectSummary(STATE.projectIndex.projects, {
          key: project.key,
          name: project.name,
          updatedAt: Date.now()
        });
        changed = true;
      }
    });
    if (changed) persistProjectIndex();
  }

  /* ──────────────────────────── RESULTS PANEL ────────────────────────────── */
  function renderResultsPanel(panel) {
    if (!panel) return;
    if (getEffectiveResultScope() === "project") {
      const shouldShowProjectList = !STATE.resultsCollapsed && (STATE.enabled || Boolean(STATE.searchTerm));
      panel.dataset.visible = String(shouldShowProjectList);
      if (!shouldShowProjectList) {
        replaceChildren(panel, []);
        return;
      }

      const results = getSearchResults();
      if (results.length === 0) {
        replaceChildren(panel, [buildEmptyState(
          STATE.searchTerm
            ? "No visible project chats match this filter."
            : "No project chats were found in this view. Open the project's chat list or scroll it to load more chats.",
          true
        )]);
        return;
      }

      replaceChildren(panel, buildResultsPanelNodes(results, { mode: "project" }));
      bindResultsPanelCheckboxes(panel);
      return;
    }
    const hasSearch = Boolean(STATE.searchTerm);
    const hasCache = STATE.cachedConversations.length > 0;
    const shouldShow = (hasSearch && !hasCache) || (hasCache && !STATE.resultsCollapsed);
    panel.dataset.visible = String(shouldShow);

    if (!shouldShow) { replaceChildren(panel, []); return; }
    if (!hasCache) {
      replaceChildren(panel, [buildEmptyState(
        "Search history is not synced yet. Click Sync all to load your full chat history first.",
        true
      )]);
      return;
    }

    const results = getSearchResults().slice(0, 250);
    if (results.length === 0) {
      replaceChildren(panel, [buildEmptyState(
        getCachedEmptyMessage(),
        STATE.selectedProjectKey !== "all" ? "warning" : "default"
      )]);
      return;
    }
    replaceChildren(panel, buildResultsPanelNodes(results));
    bindResultsPanelCheckboxes(panel);
  }

  function getCachedEmptyMessage() {
    if (STATE.selectedProjectKey === "all") return "No cached chats match this filter.";
    const project = STATE.projectIndex.projects.find(item => item.key === STATE.selectedProjectKey);
    const membership = STATE.projectIndex.memberships[STATE.selectedProjectKey];
    const projectName = project?.name || "this project";
    if (!Array.isArray(membership?.ids) || membership.ids.length === 0) {
      return `Open ${projectName} and scroll its chat list first.`;
    }
    return `No matches. Open ${projectName} in the sidebar and scroll to load more.`;
  }

  function bindResultsPanelCheckboxes(panel) {
    panel.querySelectorAll(".gptbd-result-checkbox").forEach(checkbox => {
      checkbox.addEventListener("change", event => {
        const scrollTop = panel.scrollTop;
        const id = event.target.getAttribute("data-id");
        if (!id) return;
        if (event.target.checked) STATE.selectedIds.add(id);
        else STATE.selectedIds.delete(id);
        syncCheckboxes();
        render();
        restoreResultsPanelScroll(scrollTop);
      });
    });
  }

  function restoreResultsPanelScroll(scrollTop) {
    const panel = document.querySelector("#gpt-bulk-delete-root .gptbd-results");
    if (!panel) return;
    panel.scrollTop = scrollTop;
    window.requestAnimationFrame(() => {
      panel.scrollTop = scrollTop;
    });
  }

  function shouldAutoCollapseResults(target) {
    if (STATE.resultsCollapsed || STATE.uiHidden || activeModalResolve) return false;
    const root = document.getElementById("gpt-bulk-delete-root");
    const panel = root?.querySelector(".gptbd-results");
    if (!root || !panel || panel.dataset.visible !== "true") return false;
    return !root.contains(target);
  }

  function buildYearFilters(years) {
    if (years.length === 0) return [];
    const wrap = document.createElement("div");
    wrap.className = "gptbd-year-filters";
    wrap.setAttribute("role", "group");
    wrap.setAttribute("aria-label", "Filter cached chats by year");

    ["all", ...years].forEach(year => {
      const isAll = year === "all";
      const button = document.createElement("button");
      button.type = "button";
      button.className = "gptbd-year-chip";
      button.dataset.action = "filter-year";
      button.dataset.year = String(year);
      button.dataset.active = String(String(STATE.selectedYear) === String(year));
      button.textContent = isAll ? "All" : String(year);
      wrap.appendChild(button);
    });

    return [wrap];
  }

  function buildFilterControls({ pageContext, activeScope, hasCache, showingCachedResults }) {
    const nodes = [];
    if (pageContext.mode === "project") {
      nodes.push(buildScopeSelect(pageContext, activeScope, hasCache));
    }
    if (showingCachedResults) {
      nodes.push(...buildYearFilters(getAvailableYears()));
      const knownProjects = getKnownProjects();
      if (knownProjects.length > 0) {
        nodes.push(buildProjectFilterSelect(knownProjects));
      }
    }
    return nodes;
  }

  function buildScopeSelect(pageContext, activeScope, hasCache) {
    const select = document.createElement("select");
    select.className = "gptbd-filter-select gptbd-scope-select";
    select.dataset.action = "select-scope";
    select.title = "Choose which chat list to show";
    select.setAttribute("aria-label", "Choose chat scope");

    const projectOption = document.createElement("option");
    projectOption.value = "project";
    projectOption.textContent = pageContext.projectName
      ? `This project: ${pageContext.projectName}`
      : "This project";
    select.appendChild(projectOption);

    const accountOption = document.createElement("option");
    accountOption.value = "account";
    accountOption.textContent = hasCache ? "All synced chats" : "All synced chats (sync first)";
    accountOption.disabled = !hasCache;
    select.appendChild(accountOption);

    select.value = activeScope;
    return select;
  }

  function buildProjectFilterSelect(projects) {
    if (!projects.some(project => project.key === STATE.selectedProjectKey)) {
      STATE.selectedProjectKey = "all";
    }

    const select = document.createElement("select");
    select.className = "gptbd-filter-select gptbd-project-select";
    select.dataset.action = "select-project-filter";
    select.dataset.active = String(STATE.selectedProjectKey !== "all");
    select.title = "Filter synced chats by known project";
    select.setAttribute("aria-label", "Filter by project");

    const allOption = document.createElement("option");
    allOption.value = "all";
    allOption.textContent = "All Chats";
    select.appendChild(allOption);

    projects.forEach(project => {
      const option = document.createElement("option");
      option.value = project.key;
      option.textContent = project.name;
      select.appendChild(option);
    });

    select.value = STATE.selectedProjectKey;
    return select;
  }

  /* ─────────────────────────── SIDEBAR HELPERS ──────────────────────────── */
  function revealRowActions(row) {
    [row, row.querySelector("a"), row.firstElementChild].forEach(el => {
      if (!(el instanceof HTMLElement)) return;
      ["mouseenter", "mouseover", "mousemove", "pointerenter", "pointerover"].forEach(type => {
        el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
      });
    });
  }

  function openConversationMenu(button) {
    button.scrollIntoView({ block: "center", inline: "center" });
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach(type => {
      button.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    });
  }

  function scoreMenuButton(button) {
    let score = 0;
    const ariaLabel = `${button.getAttribute("aria-label") || ""} ${button.title || ""}`.toLowerCase();
    const testId = (button.getAttribute("data-testid") || "").toLowerCase();
    const id = (button.id || "").toLowerCase();
    if (button.getAttribute("aria-haspopup") === "menu") score += 10;
    if (button.hasAttribute("aria-expanded")) score += 4;
    if (ariaLabel.includes("more")) score += 6;
    if (testId.includes("history") || testId.includes("conversation")) score += 5;
    if (id.startsWith("radix-")) score += 3;
    if (button.offsetParent !== null) score += 2;
    return score;
  }

  /* ─────────────────────────── API HELPERS ──────────────────────────────── */
  async function getAccessToken() {
    const session = await getSessionContext();
    return session?.accessToken || null;
  }

  async function getSessionContext() {
    try {
      const response = await fetch("/api/auth/session", { credentials: "include" });
      if (!response.ok) {
        switchLibraryAccount(null);
        return null;
      }
      const data = await response.json();
      const accessToken = data?.accessToken || null;
      if (!accessToken) {
        switchLibraryAccount(null);
        return null;
      }
      const accountKey = data?.user?.id || data?.account?.id || getJwtSubject(accessToken);
      if (accountKey && STATE.accountKey !== accountKey) {
        STATE.accountKey = accountKey;
        STATE.deleteCooldown = null;
        void restoreDeleteCooldown(accountKey).then(() => {
          if (isDeleteCoolingDown(accountKey)) scheduleDeleteCooldownEnd();
          render();
        });
      }
      switchLibraryAccount(accountKey || null);
      return {
        accessToken,
        accountKey
      };
    } catch (_) {
      switchLibraryAccount(null);
      return null;
    }
  }

  function switchLibraryAccount(accountKey) {
    if (accountKey && accountKey !== lastLibrarySessionAccountKey) {
      // A newly active account gets one automatic session sync even if this
      // tab previously visited it before switching away.
      libraryAutoSyncAttempts.delete(accountKey);
    }
    lastLibrarySessionAccountKey = accountKey || null;
    if (STATE.library.accountKey === accountKey) return;
    revokeLibraryThumbnails();
    if (GPTBDLibraryUi?.loadCache) {
      GPTBDLibraryUi.loadCache(STATE.library, window.localStorage, accountKey);
      return;
    }
    STATE.library.accountKey = accountKey;
    STATE.library.files = [];
    STATE.library.selectedIds.clear();
    STATE.library.cacheLoadedAt = null;
    STATE.library.syncApiAvailable = null;
    STATE.library.deleteApiAvailable = null;
    STATE.library.isComplete = false;
    STATE.library.syncing = false;
    STATE.library.syncRunId = (STATE.library.syncRunId || 0) + 1;
  }

  function getJwtSubject(token) {
    try {
      const payload = token.split(".")[1];
      if (!payload) return null;
      const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
      return JSON.parse(window.atob(normalized))?.sub || null;
    } catch (_) {
      return null;
    }
  }

  async function ensureCapabilityHealth(options = {}) {
    const force = Boolean(options.force);
    if (!force && !isCapabilityHealthStale()) return STATE.health;
    if (STATE.health.running) return STATE.health;

    STATE.health.running = true;
    try {
      const [api, ui] = await Promise.all([
        probeApiHealth(),
        Promise.resolve(probeUiHealth())
      ]);
      STATE.health = buildCapabilityHealth(api, ui);
      scheduleCapabilityHealthRefresh(STATE.health.safeMode ? CAPABILITY_RETRY_MS : CAPABILITY_REFRESH_MS);
    } finally {
      STATE.health.running = false;
      render();
    }

    if (!options.silent && STATE.health.note) showToast(STATE.health.note);
    return STATE.health;
  }

  function setupRuntimeBridge() {
    if (runtimeBridgeReady || !chrome?.runtime?.onMessage) return;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (!message || typeof message !== "object") return false;

      if (message.type === "gptbd:get-compatibility-status") {
        sendResponse({
          ok: true,
          report: createCompatibilityReport(false)
        });
        return false;
      }

      if (message.type === "gptbd:run-compatibility-check") {
        void (async () => {
          try {
            await ensureCapabilityHealth({ force: true, silent: true });
            refreshConversationRows();
            render();
            sendResponse({
              ok: true,
              report: createCompatibilityReport(true)
            });
          } catch (error) {
            sendResponse({
              ok: false,
              error: error instanceof Error ? error.message : "Compatibility check failed."
            });
          }
        })();
        return true;
      }

      return false;
    });
    runtimeBridgeReady = true;
  }

  function isCapabilityHealthStale() {
    return !STATE.health.checkedAt || (Date.now() - STATE.health.checkedAt) > CAPABILITY_REFRESH_MS;
  }

  async function probeApiHealth() {
    const accessToken = await getAccessToken();
    if (!accessToken) {
      return {
        syncAvailable: false,
        deleteApiAvailable: false,
        issues: ["ChatGPT session unavailable."]
      };
    }

    try {
      const response = await fetch("/backend-api/conversations?offset=0&limit=1", {
        credentials: "include",
        headers: { Authorization: `Bearer ${accessToken}` }
      });

      if (!response.ok) {
        return {
          syncAvailable: false,
          deleteApiAvailable: false,
          issues: [`ChatGPT API returned ${response.status}.`]
        };
      }

      const data = await response.json();
      if (!Array.isArray(data?.items)) {
        return {
          syncAvailable: false,
          deleteApiAvailable: false,
          issues: ["ChatGPT API response shape changed."]
        };
      }

      return {
        syncAvailable: true,
        deleteApiAvailable: true,
        issues: []
      };
    } catch (_) {
      return {
        syncAvailable: false,
        deleteApiAvailable: false,
        issues: ["ChatGPT API could not be reached."]
      };
    }
  }

  function probeUiHealth() {
    const rows = getConversationRows();
    if (rows.length === 0) {
      return {
        deleteUiAvailable: true,
        issues: []
      };
    }

    const hasMenuButton = rows.some(({ row }) => Boolean(findMenuButton(row)));
    return {
      deleteUiAvailable: hasMenuButton,
      issues: hasMenuButton ? [] : ["Sidebar action menu is unavailable."]
    };
  }

  function buildCapabilityHealth(api, ui) {
    const syncAvailable = Boolean(api.syncAvailable);
    const deleteApiAvailable = Boolean(api.deleteApiAvailable);
    const deleteUiAvailable = Boolean(ui.deleteUiAvailable);
    const issues = [...api.issues, ...ui.issues];
    let note = "";
    let safeMode = false;

    if (!syncAvailable && !deleteApiAvailable && !deleteUiAvailable) {
      safeMode = true;
      note = "Bulk actions paused. ChatGPT changed something.";
    } else if (!syncAvailable && deleteUiAvailable) {
      note = "Sync unavailable. Delete limited to visible chats.";
    } else if (!deleteApiAvailable && deleteUiAvailable) {
      note = "Delete fallback active. Only visible chats are safe to remove.";
    }

    return {
      checkedAt: Date.now(),
      running: false,
      syncAvailable,
      deleteApiAvailable,
      deleteUiAvailable,
      safeMode,
      note,
      issues
    };
  }

  function createCompatibilityReport(ranNow = false) {
    const health = STATE.health;
    const mode = health.safeMode
      ? "paused"
      : health.syncAvailable && health.deleteApiAvailable
        ? "healthy"
        : health.deleteUiAvailable
          ? "fallback"
          : "degraded";

    const summary = {
      healthy: "ChatGPT compatibility looks healthy.",
      fallback: "ChatGPT changed slightly. Sync or API delete is limited, but the UI fallback is still available.",
      degraded: "ChatGPT compatibility is degraded. Some actions may be unavailable.",
      paused: "Bulk actions are paused until ChatGPT compatibility recovers."
    }[mode];

    return {
      mode,
      summary,
      note: health.note || "",
      checkedAt: health.checkedAt || 0,
      ranNow,
      issues: [...health.issues],
      capabilities: {
        sync: Boolean(health.syncAvailable),
        deleteApi: Boolean(health.deleteApiAvailable),
        deleteUi: Boolean(health.deleteUiAvailable),
        // A successful Library listing does not prove delete compatibility.
        // This stays unknown until a stream delete is verified by a fresh listing.
        librarySync: STATE.library.syncApiAvailable,
        libraryDelete: STATE.library.deleteApiAvailable
      }
    };
  }

  function canDeleteSelection(ids = Array.from(STATE.selectedIds)) {
    if (ids.length === 0) return false;
    if (STATE.health.deleteApiAvailable) return true;
    if (!STATE.health.deleteUiAvailable) return false;
    return ids.every(id => {
      const row = document.querySelector(`[data-gptbd-conversation-id="${CSS.escape(id)}"]`);
      if (!row) return false;
      if (row.dataset.gptbdConversationSource === "project") return Boolean(findMenuButton(row));
      return true;
    });
  }

  function registerCapabilitySuccess(kind) {
    if (!(kind in STATE.failureCounts)) return;
    STATE.failureCounts[kind] = 0;

    if (kind === "sync") STATE.health.syncAvailable = true;
    if (kind === "deleteApi") STATE.health.deleteApiAvailable = true;
    if (kind === "deleteUi") STATE.health.deleteUiAvailable = true;

    STATE.health.safeMode = !STATE.health.syncAvailable && !STATE.health.deleteApiAvailable && !STATE.health.deleteUiAvailable;
    STATE.health.note = buildCapabilityHealth(
      { syncAvailable: STATE.health.syncAvailable, deleteApiAvailable: STATE.health.deleteApiAvailable, issues: [] },
      { deleteUiAvailable: STATE.health.deleteUiAvailable, issues: [] }
    ).note;
    STATE.health.checkedAt = Date.now();
  }

  function registerCapabilityFailure(kind, issue) {
    if (!(kind in STATE.failureCounts)) return;
    STATE.failureCounts[kind] += 1;
    if (issue && !STATE.health.issues.includes(issue)) {
      STATE.health.issues = [...STATE.health.issues, issue];
    }
    if (STATE.failureCounts[kind] < CAPABILITY_FAILURE_THRESHOLD) return;

    if (kind === "sync") STATE.health.syncAvailable = false;
    if (kind === "deleteApi") STATE.health.deleteApiAvailable = false;
    if (kind === "deleteUi") STATE.health.deleteUiAvailable = false;

    const recomputed = buildCapabilityHealth(
      {
        syncAvailable: STATE.health.syncAvailable,
        deleteApiAvailable: STATE.health.deleteApiAvailable,
        issues: STATE.health.issues
      },
      {
        deleteUiAvailable: STATE.health.deleteUiAvailable,
        issues: []
      }
    );
    STATE.health = { ...STATE.health, ...recomputed, running: false };
    STATE.health.checkedAt = Date.now();
    scheduleCapabilityHealthRefresh(CAPABILITY_RETRY_MS);
    render();
  }

  async function refreshSidebarAfterDelete() {
    const beforeIds = getConversationRows().map(({ id }) => id).join(",");
    const beforeCount = getConversationRows().length;
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));

    if (getPageContext().mode !== "project") {
      const newChatLink = Array.from(
        document.querySelectorAll('a[href="/"], a[href="/?model=auto"]')
      ).find(n => n instanceof HTMLElement);
      if (newChatLink) {
        newChatLink.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
      }
    }

    window.dispatchEvent(new Event("focus"));
    document.dispatchEvent(new Event("visibilitychange"));
    await delay(600);
    refreshConversationRows();

    const afterIds = getConversationRows().map(({ id }) => id).join(",");
    const afterCount = getConversationRows().length;
    return afterCount < beforeCount || afterIds !== beforeIds;
  }

  function removeConversationRow(id) {
    const row = document.querySelector(`[data-gptbd-conversation-id="${CSS.escape(id)}"]`);
    if (!row) return;
    row.dataset.gptbdDeleted = "true";
    row.classList.add("gptbd-row-hidden");
    row.remove();
  }

  function removeConversationFromCache(id) {
    const next = STATE.cachedConversations.filter(c => c.id !== id);
    const cacheChanged = next.length !== STATE.cachedConversations.length;
    if (cacheChanged) {
      STATE.cachedConversations = next;
      persistCache();
    }
    removeConversationFromProjectIndex(id);
  }

  function clearLocalCache() {
    STATE.cachedConversations = [];
    STATE.cacheLoadedAt = null;
    STATE.selectedYear = "all";
    STATE.selectedProjectKey = "all";
    persistCache();
    void clearSyncCheckpoint();
  }

  function buildDeleteSummary(deleted, failedCount, sidebarRefreshed, rateLimitError = null) {
    const deletedPart = `Deleted ${deleted} conversation${deleted === 1 ? "" : "s"}.`;
    if (rateLimitError instanceof GPTBDDelete.DeleteRateLimitError) {
      const waitText = formatRateLimitWait(rateLimitError.retryAfterMs);
      return `${deletedPart} ChatGPT paused delete requests; ${failedCount} selected chat${failedCount === 1 ? " was" : "s were"} left untouched. ${waitText}`;
    }
    if (failedCount > 0) {
      const refreshNote = sidebarRefreshed ? "" : " Refresh the page if the list looks stale.";
      return `${deletedPart} ${failedCount} failed — try those again from the current list.${refreshNote}`;
    }
    if (!sidebarRefreshed) return `${deletedPart} Refresh the page if the list looks stale.`;
    return deletedPart;
  }

  function buildPausedDeleteSummary(deleted, failedCount, pauseError) {
    const deletedPart = `Deleted ${deleted} conversation${deleted === 1 ? "" : "s"}.`;
    const remainingPart = `${failedCount} selected chat${failedCount === 1 ? " was" : "s were"} left untouched.`;
    if (pauseError?.reason === "auth") {
      return `${deletedPart} Your ChatGPT session changed; ${remainingPart} Refresh ChatGPT, then click Delete again.`;
    }
    if (pauseError?.reason === "timeout") {
      return `${deletedPart} A delete request timed out; ${remainingPart} Check your connection, then click Delete again.`;
    }
    return `${deletedPart} Delete paused; ${remainingPart} Click Delete again when ChatGPT is available.`;
  }

  function formatRateLimitWait(retryAfterMs) {
    if (!retryAfterMs) return "Wait a few minutes, then click Delete again.";
    if (retryAfterMs < 60 * 1000) {
      return `Wait about ${Math.ceil(retryAfterMs / 1000)} seconds, then click Delete again.`;
    }
    return `Wait about ${Math.ceil(retryAfterMs / 60000)} minutes, then click Delete again.`;
  }

  function isDeleteCoolingDown(scopeKey = STATE.accountKey) {
    return GPTBDDelete.isCooldownActive(STATE.deleteCooldown, scopeKey);
  }

  function formatDeleteCooldownMessage() {
    const remainingMs = Math.max(0, Number(STATE.deleteCooldown?.until) - Date.now());
    return `ChatGPT is rate-limiting deletes. ${formatRateLimitWait(remainingMs)}`;
  }

  async function persistDeleteCooldown(scopeKey, until) {
    STATE.deleteCooldown = { scopeKey, until };
    try {
      await chrome.storage.local.set({ [DELETE_COOLDOWN_KEY]: STATE.deleteCooldown });
    } catch (_) {}
  }

  async function restoreDeleteCooldown(scopeKey) {
    try {
      const stored = await chrome.storage.local.get(DELETE_COOLDOWN_KEY);
      const cooldown = stored?.[DELETE_COOLDOWN_KEY] || null;
      STATE.deleteCooldown = GPTBDDelete.isCooldownActive(cooldown, scopeKey) ? cooldown : null;
      if (!STATE.deleteCooldown) await chrome.storage.local.remove(DELETE_COOLDOWN_KEY);
    } catch (_) {
      STATE.deleteCooldown = null;
    }
  }

  function scheduleDeleteCooldownEnd() {
    window.clearTimeout(STATE.deleteCooldownTimer);
    const delayMs = Math.max(0, Number(STATE.deleteCooldown?.until) - Date.now());
    STATE.deleteCooldownTimer = window.setTimeout(() => {
      STATE.deleteCooldown = null;
      void chrome.storage.local.remove(DELETE_COOLDOWN_KEY);
      render();
    }, Math.min(delayMs + 50, 2 ** 31 - 1));
  }

  function scheduleCapabilityHealthRefresh(delayMs = CAPABILITY_REFRESH_MS) {
    window.clearTimeout(STATE.healthTimer);
    STATE.healthTimer = window.setTimeout(() => {
      void ensureCapabilityHealth({ force: true, silent: true });
    }, delayMs);
  }

  /* ───────────────────────────── CACHE ─────────────────────────────────── */
  function persistCache() {
    try {
      window.localStorage.setItem(CACHE_KEY, JSON.stringify({
        conversations: STATE.cachedConversations,
        loadedAt: STATE.cacheLoadedAt || Date.now()
      }));
      return true;
    } catch (_) {
      return false;
    }
  }

  async function persistSyncCheckpoint(checkpoint) {
    await chrome.storage.local.set({ [SYNC_CHECKPOINT_KEY]: checkpoint });
  }

  async function loadSyncCheckpoint(accountKey) {
    try {
      const stored = await chrome.storage.local.get(SYNC_CHECKPOINT_KEY);
      const checkpoint = stored?.[SYNC_CHECKPOINT_KEY];
      if (!checkpoint || !accountKey || checkpoint.scopeKey !== accountKey) {
        await clearSyncCheckpoint();
        return null;
      }
      const updatedAt = Number(checkpoint?.updatedAt) || 0;
      if (!updatedAt || Date.now() - updatedAt > SYNC_CHECKPOINT_MAX_AGE_MS) {
        await clearSyncCheckpoint();
        return null;
      }
      return checkpoint;
    } catch (_) {
      try { await clearSyncCheckpoint(); } catch (_) {}
      return null;
    }
  }

  async function clearSyncCheckpoint() {
    await chrome.storage.local.remove(SYNC_CHECKPOINT_KEY);
  }

  function persistProjectIndex() {
    try {
      window.localStorage.setItem(PROJECT_CACHE_KEY, JSON.stringify(STATE.projectIndex));
    } catch (_) {}
  }

  function loadCache() {
    try {
      const raw = window.localStorage.getItem(CACHE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      const conversations = Array.isArray(parsed?.conversations) ? parsed.conversations : [];
      STATE.cachedConversations = conversations.filter(item => item?.id && typeof item.title === "string");
      STATE.cacheLoadedAt = parsed?.loadedAt || null;
    } catch (_) {
      STATE.cachedConversations = [];
      STATE.cacheLoadedAt = null;
    }
  }

  function loadProjectIndex() {
    try {
      const raw = window.localStorage.getItem(PROJECT_CACHE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      const projects = Array.isArray(parsed?.projects) ? parsed.projects : [];
      const memberships = parsed?.memberships && typeof parsed.memberships === "object"
        ? parsed.memberships
        : {};

      const cleanMemberships = {};
      Object.entries(memberships).forEach(([key, value]) => {
        const ids = Array.isArray(value?.ids) ? value.ids.filter(Boolean) : [];
        if (!key || ids.length === 0) return;
        cleanMemberships[key] = {
          name: normalizeText(value?.name) || "Untitled project",
          ids: Array.from(new Set(ids)),
          updatedAt: Number(value?.updatedAt) || 0
        };
      });

      STATE.projectIndex = {
        projects: projects
          .filter(item => item?.key && item?.name && cleanMemberships[item.key])
          .map(item => ({
            key: item.key,
            name: normalizeText(item.name) || cleanMemberships[item.key].name,
            updatedAt: Number(item.updatedAt) || cleanMemberships[item.key].updatedAt || 0
          }))
          .sort((a, b) => String(a.name).localeCompare(String(b.name))),
        memberships: cleanMemberships
      };
    } catch (_) {
      STATE.projectIndex = { projects: [], memberships: {} };
    }
  }

  function removeConversationFromProjectIndex(id) {
    let changed = false;
    Object.entries(STATE.projectIndex.memberships).forEach(([key, membership]) => {
      const ids = Array.isArray(membership?.ids) ? membership.ids : [];
      const nextIds = ids.filter(existingId => existingId !== id);
      if (nextIds.length === ids.length) return;
      changed = true;
      if (nextIds.length === 0) {
        delete STATE.projectIndex.memberships[key];
        STATE.projectIndex.projects = STATE.projectIndex.projects.filter(project => project.key !== key);
      } else {
        STATE.projectIndex.memberships[key] = { ...membership, ids: nextIds, updatedAt: Date.now() };
      }
    });
    if (!changed) return;
    if (STATE.selectedProjectKey !== "all" && !STATE.projectIndex.memberships[STATE.selectedProjectKey]) {
      STATE.selectedProjectKey = "all";
    }
    persistProjectIndex();
  }

  async function loadPreferences() {
    if (!chrome?.storage?.local) {
      STATE.mode = isLibraryRoute() ? "library" : "chats";
      return;
    }
    try {
      const stored = await chrome.storage.local.get([
        UI_HIDDEN_KEY,
        TOOLBAR_MODE_KEY,
        SKIP_DELETE_WARNING_KEY,
        REVIEW_SESSION_COUNT_KEY,
        REVIEW_PROMPT_HIDDEN_KEY
      ]);
      STATE.uiHidden = Boolean(stored?.[UI_HIDDEN_KEY]);
      STATE.mode = isLibraryRoute() || stored?.[TOOLBAR_MODE_KEY] === "library" ? "library" : "chats";
      STATE.skipDeleteWarning = Boolean(stored?.[SKIP_DELETE_WARNING_KEY]);
      STATE.reviewSessionCount = normalizeStoredCount(stored?.[REVIEW_SESSION_COUNT_KEY]);
      STATE.reviewPromptHidden = Boolean(stored?.[REVIEW_PROMPT_HIDDEN_KEY]);
      await countReviewSession();
    } catch (_) {
      STATE.uiHidden = false;
      STATE.mode = isLibraryRoute() ? "library" : "chats";
      STATE.skipDeleteWarning = false;
      STATE.reviewSessionCount = 0;
      STATE.reviewPromptHidden = false;
    }
  }

  async function setUiHiddenPreference(hidden) {
    STATE.uiHidden = hidden;
    render();
    if (!hidden && STATE.mode === "library") void ensureLibraryCacheForCurrentAccount();
    if (!chrome?.storage?.local) return;
    try {
      await chrome.storage.local.set({ [UI_HIDDEN_KEY]: hidden });
    } catch (_) {}
  }

  async function setToolbarModePreference(mode) {
    if (!chrome?.storage?.local) return;
    try {
      await chrome.storage.local.set({ [TOOLBAR_MODE_KEY]: mode === "library" ? "library" : "chats" });
    } catch (_) {}
  }

  function isLibraryRoute() {
    return GPTBDLibraryUi?.isLibraryPath?.(window.location.pathname)
      || /^\/(?:library|space\/files)(?:\/|$)/i.test(window.location.pathname || "");
  }

  async function setSkipDeleteWarningPreference(skip) {
    STATE.skipDeleteWarning = skip;
    if (!chrome?.storage?.local) return;
    try {
      await chrome.storage.local.set({ [SKIP_DELETE_WARNING_KEY]: skip });
    } catch (_) {}
  }

  async function hideReviewPrompt() {
    STATE.reviewPromptHidden = true;
    render();
    if (!chrome?.storage?.local) return;
    try {
      await chrome.storage.local.set({ [REVIEW_PROMPT_HIDDEN_KEY]: true });
    } catch (_) {}
  }

  function observePreferenceChanges() {
    if (!chrome?.storage?.onChanged || observePreferenceChanges.bound) return;
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local") return;
      let shouldRender = false;
      if (changes?.[UI_HIDDEN_KEY]) {
        STATE.uiHidden = Boolean(changes[UI_HIDDEN_KEY].newValue);
        shouldRender = true;
      }
      if (changes?.[SKIP_DELETE_WARNING_KEY]) {
        STATE.skipDeleteWarning = Boolean(changes[SKIP_DELETE_WARNING_KEY].newValue);
      }
      if (changes?.[REVIEW_SESSION_COUNT_KEY]) {
        STATE.reviewSessionCount = normalizeStoredCount(changes[REVIEW_SESSION_COUNT_KEY].newValue);
        shouldRender = true;
      }
      if (changes?.[REVIEW_PROMPT_HIDDEN_KEY]) {
        STATE.reviewPromptHidden = Boolean(changes[REVIEW_PROMPT_HIDDEN_KEY].newValue);
        shouldRender = true;
      }
      if (shouldRender) render();
    });
    observePreferenceChanges.bound = true;
  }

  async function countReviewSession() {
    if (STATE.reviewPromptHidden || !chrome?.storage?.local || isReviewSessionMarked()) return;
    if (!markReviewSession()) return;
    STATE.reviewSessionCount += 1;
    try {
      await chrome.storage.local.set({ [REVIEW_SESSION_COUNT_KEY]: STATE.reviewSessionCount });
    } catch (_) {}
  }

  function shouldShowReviewPrompt() {
    return !STATE.reviewPromptHidden && STATE.reviewSessionCount >= REVIEW_PROMPT_THRESHOLD;
  }

  function getReviewUrl() {
    return isFirefox() ? FIREFOX_REVIEW_URL : CHROME_REVIEW_URL;
  }

  function isFirefox() {
    return /firefox/i.test(window.navigator?.userAgent || "");
  }

  function normalizeStoredCount(value) {
    const numeric = Number(value);
    return Number.isFinite(numeric) && numeric > 0 ? Math.floor(numeric) : 0;
  }

  function isReviewSessionMarked() {
    try {
      return window.sessionStorage.getItem(REVIEW_SESSION_MARK_KEY) === "true";
    } catch (_) {
      return true;
    }
  }

  function markReviewSession() {
    try {
      window.sessionStorage.setItem(REVIEW_SESSION_MARK_KEY, "true");
      return true;
    } catch (_) {}
    return false;
  }

  /* ──────────────────────────── UTILITIES ───────────────────────────────── */
  function normalizeText(value) {
    return (value || "").replace(/\s+/g, " ").trim();
  }

  function resetModalToDeleteDefaults(modal) {
    if (!(modal instanceof HTMLElement)) return;
    const subtitleEl = modal.querySelector(".gptbd-modal__subtitle");
    const warningWrap = modal.querySelector(".gptbd-modal__warning");
    const warningText = modal.querySelector(".gptbd-modal__warning-text");
    const warningCheckWrap = modal.querySelector('[data-role="modal-warning-check"]')?.closest(".gptbd-modal__check");
    const warningCheckLabel = warningCheckWrap?.querySelector(".gptbd-modal__check-label");
    const skipWarningCheckWrap = modal.querySelector('[data-role="modal-skip-warning-check"]')?.closest(".gptbd-modal__check");

    if (subtitleEl) subtitleEl.textContent = DEFAULT_DELETE_MODAL_SUBTITLE;
    if (warningWrap) warningWrap.hidden = false;
    if (warningText) warningText.textContent = DEFAULT_DELETE_MODAL_WARNING;
    if (warningCheckWrap) warningCheckWrap.hidden = false;
    if (warningCheckLabel) warningCheckLabel.textContent = "I understand this delete is permanent and cannot be recovered.";
    if (skipWarningCheckWrap) skipWarningCheckWrap.hidden = false;
  }

  function createTemplateFragment(html) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(`<body>${html}</body>`, "text/html");
    const fragment = document.createDocumentFragment();
    Array.from(doc.body.childNodes).forEach(node => {
      fragment.appendChild(document.importNode(node, true));
    });
    return fragment;
  }

  function replaceChildren(parent, children) {
    if (!(parent instanceof Element)) return;
    parent.replaceChildren(...children);
  }

  function buildDeletePreviewItems(shownTitles, remaining) {
    const nodes = shownTitles.map(title => buildPreviewItem(title));
    if (remaining > 0) {
      const more = document.createElement("div");
      more.className = "gptbd-modal__preview-more";
      more.textContent = `+\u202f${remaining}\u00a0more\u2026`;
      nodes.push(more);
    }
    return nodes;
  }

  function buildClearCachePreviewItems() {
    return [
      buildPreviewItem("Your chats in ChatGPT will not be deleted."),
      buildPreviewItem("You will need to click Sync all again to restore the cached list.")
    ];
  }

  function buildPreviewItem(text) {
    const item = document.createElement("div");
    item.className = "gptbd-modal__preview-item";

    const bullet = document.createElement("span");
    bullet.className = "gptbd-modal__preview-bullet";
    bullet.setAttribute("aria-hidden", "true");

    const label = document.createElement("span");
    label.className = "gptbd-modal__preview-text";
    label.textContent = text;

    item.append(bullet, label);
    return item;
  }

  function buildEmptyState(message, variant = "default") {
    const empty = document.createElement("div");
    const normalizedVariant = variant === true ? "notice" : variant;
    empty.className = `gptbd-empty${normalizedVariant && normalizedVariant !== "default" ? ` gptbd-empty--${normalizedVariant}` : ""}`;
    empty.textContent = message;
    return empty;
  }

  function buildResultsPanelNodes(results, options = {}) {
    const nodes = [buildResultsHeader(options)];
    results.forEach(conversation => nodes.push(buildResultRow(conversation, options)));
    return nodes;
  }

  function buildResultsHeader(options = {}) {
    const projectMode = options.mode === "project";
    const header = document.createElement("div");
    header.className = `gptbd-results-header${projectMode ? " gptbd-results-header--project" : ""}`;

    const title = document.createElement("label");
    title.className = "gptbd-results-header__title";
    const selectAll = document.createElement("input");
    selectAll.type = "checkbox";
    selectAll.className = "gptbd-result-checkbox";
    selectAll.dataset.role = "chat-select-all-checkbox";
    const ids = getSelectableConversationIds();
    const selectedCount = ids.filter(id => STATE.selectedIds.has(id)).length;
    selectAll.checked = ids.length > 0 && selectedCount === ids.length;
    selectAll.indeterminate = selectedCount > 0 && selectedCount < ids.length;
    selectAll.disabled = STATE.deleting || STATE.syncingAll || STATE.library.deletePending
      || ids.length === 0 || !canDeleteSelection(ids);
    selectAll.setAttribute("aria-label", "Select all chats matching the current filters");
    selectAll.title = "Select or clear all chats matching the current filters, including those beyond the displayed list";
    selectAll.addEventListener("change", () => {
      if (STATE.deleting || STATE.syncingAll || STATE.library.deletePending) return;
      const currentIds = getSelectableConversationIds();
      if (!canDeleteSelection(currentIds)) return;
      const scrollTop = header.parentElement?.scrollTop || 0;
      currentIds.forEach(id => selectAll.checked ? STATE.selectedIds.add(id) : STATE.selectedIds.delete(id));
      STATE.lastSelectedId = null;
      syncCheckboxes();
      render();
      restoreResultsPanelScroll(scrollTop);
    });
    title.append(selectAll, document.createTextNode(projectMode ? "Project chat" : "Chat"));

    const open = document.createElement("span");
    open.className = "gptbd-results-header__open";
    open.textContent = "Open";

    if (projectMode) {
      header.append(title, open);
      return header;
    }

    const date = document.createElement("span");
    date.className = "gptbd-results-header__date";
    date.textContent = "Date";

    header.append(title, date, open);
    return header;
  }

  function buildResultRow(conversation, options = {}) {
    const projectMode = options.mode === "project";
    const row = document.createElement("div");
    row.className = `gptbd-result${projectMode ? " gptbd-result--project" : ""}`;

    const label = document.createElement("label");
    label.className = "gptbd-result-main";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "gptbd-result-checkbox";
    checkbox.dataset.id = conversation.id;
    checkbox.checked = STATE.selectedIds.has(conversation.id);

    const title = document.createElement("span");
    title.className = "gptbd-result-title";
    title.textContent = conversation.title || "Untitled chat";

    label.append(checkbox, title);

    const open = document.createElement("a");
    open.className = "gptbd-result-open";
    open.href = `/c/${encodeURIComponent(conversation.id)}`;
    open.target = "_blank";
    open.rel = "noopener noreferrer";
    open.textContent = "Open ↗";

    if (projectMode) {
      row.append(label, open);
      return row;
    }

    const date = document.createElement("span");
    const dateText = formatConversationDate(conversation.updateTime);
    date.className = "gptbd-result-date";
    date.title = dateText;
    date.textContent = dateText;

    row.append(label, date, open);
    return row;
  }

  function isElementVisible(element) {
    if (!(element instanceof HTMLElement)) return false;
    if (element.hidden) return false;
    if (element.getAttribute("aria-hidden") === "true") return false;
    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") return false;
    if (style.pointerEvents === "none") return false;
    return element.getClientRects().length > 0;
  }

  function isScrollable(element) {
    if (!(element instanceof HTMLElement)) return false;
    const style = window.getComputedStyle(element);
    const overflowY = style.overflowY;
    return /(auto|scroll|overlay)/.test(overflowY) && element.scrollHeight > element.clientHeight + 4;
  }

  function getVisibleMenuSurfaces() {
    return Array.from(document.querySelectorAll([
      '[role="menu"]',
      '[data-radix-menu-content]',
      '[data-radix-popper-content-wrapper]'
    ].join(", "))).filter(element => {
      return isElementVisible(element) && !element.closest("#gpt-bulk-delete-root");
    });
  }

  async function waitForMenuSurface(menuSurfacesBefore = []) {
    return waitFor(() => {
      const beforeSet = new Set(menuSurfacesBefore);
      const surfaces = getVisibleMenuSurfaces();
      const newSurface = surfaces.find(surface => !beforeSet.has(surface));
      if (newSurface) return newSurface;
      return surfaces.find(surface => surface.querySelector(SELECTORS.menuItems)) || null;
    }, 2500);
  }

  function getVisibleDialogs() {
    return Array.from(document.querySelectorAll(SELECTORS.dialogs)).filter(dialog => {
      return isElementVisible(dialog) && !dialog.closest("#gpt-bulk-delete-root");
    });
  }

  function normalizeSearchTerm(value) {
    return normalizeText(value).toLowerCase();
  }

  function filterCachedResults(results) {
    const projectMembership = getSelectedProjectMembership();
    return results.filter(conversation => {
      if (projectMembership && !projectMembership.has(conversation.id)) {
        return false;
      }
      if (STATE.selectedYear !== "all" && getConversationYear(conversation) !== String(STATE.selectedYear)) {
        return false;
      }
      if (STATE.searchTerm && !matchesSearch(conversation.title, STATE.searchTerm)) {
        return false;
      }
      return true;
    });
  }

  function getSelectedProjectMembership() {
    if (STATE.selectedProjectKey === "all") return null;
    const membership = STATE.projectIndex.memberships[STATE.selectedProjectKey];
    if (!Array.isArray(membership?.ids)) return new Set();
    return new Set(membership.ids);
  }

  function getAvailableYears() {
    const years = new Set();
    STATE.cachedConversations.forEach(conversation => {
      const year = getConversationYear(conversation);
      if (year) years.add(year);
    });
    return Array.from(years).sort((a, b) => Number(b) - Number(a));
  }

  function getConversationYear(conversation) {
    const timestamp = getConversationTimestamp(conversation);
    if (!timestamp) return null;
    return String(new Date(timestamp).getFullYear());
  }

  function matchesSearch(title, searchTerm) {
    const normalized = normalizeText(title).toLowerCase();
    if (!STATE.exactSearch) return normalized.includes(searchTerm);
    const keywords = searchTerm.split(/\s+/).filter(Boolean);
    if (keywords.length === 0) return true;
    return keywords.every(kw => new RegExp(`(^|[^a-z0-9])${escapeRegExp(kw)}([^a-z0-9]|$)`, "i").test(normalized));
  }

  function sortCachedResults(results) {
    return results.slice().sort((a, b) => {
      const aTime = getConversationTimestamp(a);
      const bTime = getConversationTimestamp(b);
      if (aTime !== bTime) {
        return STATE.cachedSortOrder === "oldest" ? aTime - bTime : bTime - aTime;
      }
      return a.title.localeCompare(b.title);
    });
  }

  function getConversationTimestamp(conversation) {
    const timestamp = conversation?.updateTime ? Date.parse(conversation.updateTime) : 0;
    return Number.isFinite(timestamp) ? timestamp : 0;
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function formatLastSync(timestamp) {
    if (!timestamp) return "never";
    const date = new Date(timestamp);
    if (Number.isNaN(date.getTime())) return "unknown";
    return new Intl.DateTimeFormat(undefined, {
      month: "short", day: "numeric",
      hour: "numeric", minute: "2-digit"
    }).format(date);
  }

  function formatConversationDate(timestamp) {
    if (!timestamp) return "Unknown";
    const date = new Date(timestamp);
    if (Number.isNaN(date.getTime())) return "Unknown";
    return new Intl.DateTimeFormat(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric"
    }).format(date);
  }

  function escapeHtml(value) {
    return String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function delay(ms) {
    return new Promise(resolve => window.setTimeout(resolve, ms));
  }

  /* ─────────────────────────── INIT ─────────────────────────────────────── */
  async function init() {
    GPTBDLibraryUi?.purgeLegacyCaches?.(window.localStorage);
    loadCache();
    loadProjectIndex();
    await loadPreferences();
    boot();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => { void init(); }, { once: true });
  } else {
    void init();
  }
})();
